# THẨM PHÁN TỐI CAO — AI Courtroom

Web game mô phỏng phiên tòa Việt Nam với nhân vật trả lời tự do thông qua OpenAI API. Giao diện và máy chủ nằm trong cùng ứng dụng Node.js. API key chỉ ở máy chủ, không đưa vào JavaScript trình duyệt.

## Chạy thử trên máy tính

1. Cài Node.js 20 trở lên.
2. Giải nén thư mục dự án.
3. Mở Terminal/CMD tại thư mục này, chạy `npm install`.
4. Sao chép `.env.example` thành `.env`.
5. Mở `.env`, đặt `OPENAI_API_KEY` bằng API key riêng của bạn. Có thể thay `OPENAI_MODEL` bằng model đang có quyền dùng trong tài khoản API.
6. Chạy `npm start`.
7. Mở `http://localhost:3000`.

**Lưu ý:** API của OpenAI được tính phí riêng theo mức sử dụng và không tự động nằm trong gói ChatGPT. Không chia sẻ API key, không đưa `.env` lên GitHub, không nhúng key vào `public/app.js`.

## Triển khai để có đường link công khai (Render + GitHub)

### A. Đưa code lên GitHub

1. Đăng nhập GitHub và tạo repository mới, nên để **Private** nếu chỉ dùng cá nhân.
2. Tải/giải nén thư mục dự án trên máy tính.
3. Dùng Git để đưa toàn bộ file dự án lên repository. Không tải `.env` hoặc API key lên GitHub; `.gitignore` đã loại `.env`.

Nếu chỉ có điện thoại, có thể dùng giao diện web GitHub để tạo repo và tải các file lên, nhưng thao tác nhiều file thường dễ hơn trên máy tính.

### B. Tạo website trên Render

1. Tạo tài khoản Render và kết nối GitHub.
2. Chọn **New → Web Service**, chọn repository dự án.
3. Đặt Runtime là **Node** (nếu được hỏi), Build Command `npm install`, Start Command `npm start`.
4. Trong mục **Environment**, thêm `OPENAI_API_KEY` với giá trị API key; thêm `OPENAI_MODEL` với tên model API mà tài khoản bạn được phép dùng.
5. Chọn **Create Web Service** và chờ quá trình deploy hoàn tất.
6. Render cấp một URL dạng `https://ten-dich-vu.onrender.com`. Mở link đó để chơi và gửi link cho người khác.

Tệp `render.yaml` có sẵn cấu hình gợi ý nếu dùng Render Blueprint. Không đưa giá trị bí mật vào `render.yaml`.

### Chi phí và giới hạn

- Hosting: Render có các gói khác nhau; gói miễn phí có thể ngủ khi không hoạt động và lần mở lại đầu tiên sẽ chậm. Chính sách/gói có thể thay đổi.
- AI: OpenAI API được tính phí riêng; đặt giới hạn chi tiêu/cảnh báo trong trang quản lý API trước khi dùng rộng rãi.
- URL công khai có nghĩa người khác có thể thử gọi AI từ website. Mẫu này giới hạn tần suất request cơ bản, nhưng trước khi chia sẻ rộng nên bổ sung đăng nhập, hạn mức theo người dùng, chống lạm dụng và theo dõi chi phí.
- Dữ liệu ván chơi hiện được giữ ở trình duyệt trong lúc chơi và gửi đến API khi cần trả lời; máy chủ không lưu lịch sử vào cơ sở dữ liệu. Đừng nhập thông tin cá nhân thật.

## Tính năng

- Sinh hồ sơ vụ án hư cấu mới.
- Hỏi tự do nhân vật, có lịch sử hội thoại gần đây làm ngữ cảnh.
- Giai đoạn khai mạc, xét hỏi, tranh luận, nghị án và tuyên án.
- Bảng điểm mô phỏng sau phán quyết và xuất biên bản TXT.

## Lưu ý pháp lý

Đây là game giáo dục, không phải sản phẩm chính thức của Tòa án/Viện kiểm sát Việt Nam. AI có thể sai về thủ tục, điều luật hoặc tình tiết. Kiểm tra văn bản pháp luật chính thức và không dùng kết quả game cho vụ việc thật.
