import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-astra';
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], fontSrc: ["'self'", 'data:'], objectSrc: ["'none'"], frameAncestors: ["'none'"]
} }}));
app.use(express.json({ limit: '80kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 25, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(client), model: MODEL }));

const systemBase = `Bạn là Game Master của trò chơi nhập vai giáo dục “THẨM PHÁN TỐI CAO — PHÁN QUYẾT CỦA BẠN”, mô phỏng phiên tòa hình sự tại Việt Nam.
Luôn trả lời bằng tiếng Việt tự nhiên, phân biệt rõ dữ kiện đã biết, lời khai, suy luận và điều chưa rõ. Đây là mô phỏng giáo dục, không phải tư vấn pháp lý chính thức. Không khẳng định điều luật/mức án cụ thể nếu không chắc; hãy ghi rõ cần đối chiếu văn bản pháp luật hiện hành. Tôn trọng nguyên tắc suy đoán vô tội, quyền bào chữa, tranh tụng và đánh giá chứng cứ khách quan.
Vụ án là hư cấu, không dùng tên hoặc thông tin nhận dạng người thật. Không để người chơi biết trước “sự thật ẩn” trước giai đoạn phù hợp. Nhân vật chỉ được biết những gì họ có thể biết; có thể nhớ nhầm, lo sợ, quanh co hoặc nói thật theo hồ sơ nhân vật nhưng không tự tiện thay đổi chứng cứ đã xác lập.
Không đưa lựa chọn A/B/C khi người chơi hỏi nhân vật. Trả lời đúng vai và đúng câu hỏi. Đừng tự kết thúc phiên tòa hoặc chuyển giai đoạn nếu Thẩm phán chưa yêu cầu. Tránh miêu tả bạo lực đồ họa.`;

async function askAI(input, maxOutputTokens = 1200) {
  if (!client) {
    const err = new Error('AI chưa được cấu hình. Chủ trang cần thêm OPENAI_API_KEY trong biến môi trường của máy chủ.');
    err.status = 503;
    throw err;
  }
  const response = await client.responses.create({
    model: MODEL,
    instructions: systemBase,
    input,
    max_output_tokens: maxOutputTokens,
    store: false
  });
  return response.output_text?.trim() || 'Tôi chưa thể trả lời lúc này. Xin Thẩm phán thử lại.';
}

app.post('/api/new-case', async (req, res, next) => {
  try {
    const text = await askAI(`Tạo một hồ sơ vụ án hình sự hư cấu mới, hợp lý, không giống một kịch bản khuôn mẫu. Trả lời JSON hợp lệ, không markdown, đúng cấu trúc:
{
 "number": số nguyên,
 "title": "Tên vụ án",
 "summary": "Tóm tắt công khai 2-4 câu, không tiết lộ sự thật ẩn",
 "allegedOffense": "Tội danh bị truy tố/cáo trạng trong kịch bản (nếu dùng điều luật, ghi rõ mô phỏng và cần kiểm tra lại)",
 "location": "Địa điểm hư cấu",
 "date": "Thời điểm hư cấu",
 "participants": [{"name":"...","role":"Bị cáo/Kiểm sát viên/Luật sư bào chữa/...","description":"mô tả công khai ngắn"}],
 "evidence": [{"id":"E1","title":"...","description":"chỉ nội dung công khai; có thể có điểm cần kiểm tra"}],
 "hiddenTruth": "sự thật thiết kế dành cho đánh giá cuối vụ, không hiển thị trong UI trước khi tuyên án",
 "characterSecrets": {"Tên nhân vật":"điều nhân vật thực sự biết/động cơ/độ tin cậy"},
 "legalNotes": "những vấn đề pháp lý cần cân nhắc, tránh kết luận quá chắc"
}
Tạo ít nhất 3 người tham gia ngoài chủ tọa và ít nhất 3 chứng cứ có thể tranh luận. Có tình tiết mâu thuẫn nhưng không quá dễ đoán. Chỉ dùng vụ việc không đồ họa. number=${Number(req.body?.number || 1)}.`, 1800);
    const jsonStart = text.indexOf('{');
    const jsonEnd = text.lastIndexOf('}');
    if (jsonStart < 0 || jsonEnd <= jsonStart) throw new Error('AI chưa trả hồ sơ theo định dạng hợp lệ. Hãy thử tạo lại.');
    const caseFile = JSON.parse(text.slice(jsonStart, jsonEnd + 1));
    res.json({ caseFile });
  } catch (e) { next(e); }
});

app.post('/api/turn', async (req, res, next) => {
  try {
    const { action, caseFile, stage, role, question, history, verdict } = req.body || {};
    if (!caseFile || typeof caseFile !== 'object') return res.status(400).json({ error: 'Thiếu hồ sơ vụ án.' });
    let prompt = '';
    if (action === 'speak') {
      if (!String(question || '').trim()) return res.status(400).json({ error: 'Hãy nhập câu hỏi hoặc yêu cầu.' });
      prompt = `HỒ SƠ VỤ ÁN (bao gồm dữ kiện công khai và bí mật thiết kế; không được tiết lộ bí mật trừ khi lời khai phù hợp):\n${JSON.stringify(caseFile)}\nGIAI ĐOẠN: ${stage}\nNHÂN VẬT ĐANG TRẢ LỜI: ${role}\nDIỄN BIẾN GẦN ĐÂY: ${JSON.stringify((history || []).slice(-12))}\nCÂU HỎI NGUYÊN VĂN CỦA CHỦ TỌA: ${String(question).slice(0, 3000)}\nHãy nhập vai ${role}, trả lời trực tiếp, tự nhiên, phù hợp tính cách và những gì nhân vật biết. Không tự đổi chứng cứ, không viết thay lời Thẩm phán, không đưa menu lựa chọn. Nếu câu hỏi chưa rõ, nhân vật có thể yêu cầu làm rõ.`;
    } else if (action === 'proceed') {
      prompt = `Dựa vào hồ sơ sau, tạo phần mở đầu/thủ tục cho giai đoạn được yêu cầu: ${stage}.\nHỒ SƠ: ${JSON.stringify(caseFile)}\nLỊCH SỬ: ${JSON.stringify((history || []).slice(-10))}\nHãy chỉ diễn vai phù hợp (thư ký, chủ tọa theo yêu cầu, hoặc thông báo thủ tục), nêu thông tin thực sự cần thiết để người chơi tiếp tục tự điều hành. Không tự chuyển sang giai đoạn kế tiếp và không tuyên án thay người chơi.`;
    } else if (action === 'closing') {
      prompt = `GIAI ĐOẠN TRANH LUẬN. Dựa trên hồ sơ và lịch sử, viết lần lượt nhưng ngắn gọn phần luận tội của Kiểm sát viên, quan điểm bào chữa của luật sư, quan điểm bảo vệ bị hại nếu phù hợp, và lời nói sau cùng của bị cáo. Mỗi ý kiến phải dựa trên chứng cứ đã xuất hiện; không tiết lộ bí mật chưa được làm rõ, không đưa ra nhiều lựa chọn cho Thẩm phán.\nHỒ SƠ: ${JSON.stringify(caseFile)}\nLỊCH SỬ: ${JSON.stringify((history || []).slice(-18))}`;
    } else if (action === 'deliberate') {
      prompt = `GIAI ĐOẠN NGHỊ ÁN. Đóng vai hai Hội thẩm nhân dân độc lập. Nêu nhận định riêng của từng người về chứng cứ, điểm mâu thuẫn, vấn đề pháp lý và những điều còn thiếu; không quyết định thay Chủ tọa. Có thể bất đồng một cách hợp lý. Chỉ dựa vào hồ sơ và diễn biến dưới đây.\nHỒ SƠ: ${JSON.stringify(caseFile)}\nDIỄN BIẾN: ${JSON.stringify((history || []).slice(-24))}`;
    } else if (action === 'score') {
      if (!verdict || typeof verdict !== 'object') return res.status(400).json({ error: 'Thiếu nội dung phán quyết.' });
      prompt = `Đánh giá kết thúc ván chơi. Đây là phản hồi giáo dục chứ không phải phán quyết pháp lý. So sánh quyết định của người chơi với hồ sơ, chứng cứ đã tranh tụng, quyền tố tụng và hiddenTruth. Không đánh đồng “kết quả trùng sự thật ẩn” với “đúng luật” nếu lập luận/chứng cứ không đủ. Trả về JSON hợp lệ, không markdown:
{"legalAccuracy":0,"fairness":0,"judgeReputation":0,"summary":"...","strengths":["..."],"risks":["..."],"hiddenTruthReveal":"...","legalCaution":"..."}
Các điểm 0-100. Đánh giá thận trọng, giải thích vì sao; không tuyên bố là kết luận chuyên môn chính thức.
HỒ SƠ: ${JSON.stringify(caseFile)}\nLỊCH SỬ: ${JSON.stringify((history || []).slice(-35))}\nPHÁN QUYẾT NGƯỜI CHƠI: ${JSON.stringify(verdict)}`;
    } else {
      return res.status(400).json({ error: 'Hành động không hợp lệ.' });
    }
    const answer = await askAI(prompt, action === 'score' ? 1500 : 1200);
    if (action === 'score') {
      const a = answer.indexOf('{'); const b = answer.lastIndexOf('}');
      if (a >= 0 && b > a) {
        try { return res.json({ result: JSON.parse(answer.slice(a, b + 1)) }); } catch {}
      }
      return res.json({ result: { legalAccuracy: 50, fairness: 50, judgeReputation: 50, summary: answer, strengths: [], risks: [], hiddenTruthReveal: caseFile.hiddenTruth || 'Không có dữ liệu.', legalCaution: 'Không đọc được bảng điểm tự động; hãy xem phần nhận xét.' } });
    }
    res.json({ answer });
  } catch (e) { next(e); }
});

app.use((err, _req, res, _next) => {
  console.error('Request failed:', err?.status || '', err?.message || 'unknown');
  if (res.headersSent) return;
  const status = err.status || (err.code === 'invalid_api_key' ? 401 : 500);
  let message = 'Có lỗi khi gọi AI. Hãy kiểm tra cấu hình máy chủ và thử lại.';
  if (status === 503) message = err.message;
  else if (status === 401) message = 'API key chưa hợp lệ. Chủ trang cần kiểm tra OPENAI_API_KEY trên máy chủ.';
  else if (status === 429) message = 'Dịch vụ AI đang giới hạn yêu cầu hoặc hết hạn mức. Hãy chờ rồi thử lại.';
  else if (err instanceof SyntaxError) message = 'Dữ liệu gửi lên chưa hợp lệ.';
  res.status(status).json({ error: message });
});

app.listen(PORT, '0.0.0.0', () => console.log(`Thẩm Phán Tối Cao đang chạy ở cổng ${PORT}; model=${MODEL}; AI=${Boolean(client)}`));
