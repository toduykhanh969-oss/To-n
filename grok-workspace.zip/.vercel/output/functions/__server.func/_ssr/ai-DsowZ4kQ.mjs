import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-DsowZ4kQ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var openCase_createServerFn_handler = createServerRpc({
	id: "1c0fa82bd1f18d273955ad4029c7efb66ad651541243491f542a35508218a299",
	name: "openCase",
	filename: "src/lib/court/ai.ts"
}, (opts) => openCase.__executeServer(opts));
var openCase = createServerFn({ method: "POST" }).validator((input) => input).handler(openCase_createServerFn_handler, async ({ data }) => {
	const { runOpen } = await import("./engine.server-BPjsSmQx.mjs");
	return runOpen(data);
});
var playTurn_createServerFn_handler = createServerRpc({
	id: "154b19670001415e4b91bf897d41f5c6120536c63bb72fe7fce0d15a693ef256",
	name: "playTurn",
	filename: "src/lib/court/ai.ts"
}, (opts) => playTurn.__executeServer(opts));
var playTurn = createServerFn({ method: "POST" }).validator((input) => input).handler(playTurn_createServerFn_handler, async ({ data }) => {
	const { runTurn } = await import("./engine.server-BPjsSmQx.mjs");
	return runTurn(data);
});
//#endregion
export { openCase_createServerFn_handler, playTurn_createServerFn_handler };
