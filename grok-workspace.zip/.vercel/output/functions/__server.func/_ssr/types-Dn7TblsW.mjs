//#region node_modules/.nitro/vite/services/ssr/assets/types-Dn7TblsW.js
var PHASE_ORDER = [
	"khai-mac",
	"xet-hoi",
	"tranh-luan",
	"nghi-an",
	"tuyen-an",
	"ket-thuc"
];
var PHASE_LABEL = {
	"khai-mac": "Khai mạc",
	"xet-hoi": "Xét hỏi",
	"tranh-luan": "Tranh luận",
	"nghi-an": "Nghị án",
	"tuyen-an": "Tuyên án",
	"ket-thuc": "Đã tuyên",
	hoan: "Hoãn phiên"
};
//#endregion
export { PHASE_ORDER as n, PHASE_LABEL as t };
