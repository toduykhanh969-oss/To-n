import { n as PHASE_ORDER } from "./types-Dn7TblsW.mjs";
import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/engine.server-BPjsSmQx.js
var cached = null;
function key() {
	if (!cached) {
		const material = process.env.XAI_API_KEY || "preview-seal";
		cached = scryptSync(material, "tptc-seal-v1", 32);
	}
	return cached;
}
function sealDossier(data) {
	const iv = randomBytes(12);
	const cipher = createCipheriv("aes-256-gcm", key(), iv);
	const enc = Buffer.concat([cipher.update(JSON.stringify(data), "utf8"), cipher.final()]);
	const tag = cipher.getAuthTag();
	return Buffer.concat([
		iv,
		tag,
		enc
	]).toString("base64url");
}
function openDossier(sealed) {
	const buf = Buffer.from(sealed, "base64url");
	if (buf.length < 29) throw new Error("Hồ sơ mật không mở được.");
	const iv = buf.subarray(0, 12);
	const tag = buf.subarray(12, 28);
	const enc = buf.subarray(28);
	const decipher = createDecipheriv("aes-256-gcm", key(), iv);
	decipher.setAuthTag(tag);
	const json = Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
	return JSON.parse(json);
}
var THEMES = [
	"án mạng trong gia đình, ranh giới phòng vệ chính đáng và giết người",
	"tham ô và nhận hối lộ ở một ban quản lý dự án, dòng tiền rối",
	"cướp tài sản ban đêm, nhân chứng mâu thuẫn, nghi đồng phạm chưa bị truy tố",
	"tai nạn giao thông chết người: vi phạm giao thông hay giết người",
	"lừa đảo qua hợp đồng, ranh giới tội phạm và tranh chấp dân sự",
	"cố ý gây thương tích, tỷ lệ thương tật trong giám định có chỗ không khớp",
	"vận chuyển trái phép chất ma túy, bị cáo kêu oan bị gài",
	"tranh chấp đất nổ ra hủy hoại tài sản và thương tích",
	"sập giàn giáo, trách nhiệm của người chỉ huy thi công",
	"giữ người trái pháp luật để đòi nợ, có dấu hiệu tổ chức",
	"khai thác khoáng sản trái phép gây hậu quả nghiêm trọng",
	"làm giả hồ sơ và lừa đảo chiếm đoạt tài sản của nhiều bị hại"
];
var SYSTEM_OPEN = `Bạn là kiến trúc sư hồ sơ vụ án cho trò chơi nhập vai THẨM PHÁN TỐI CAO. Bạn dựng MỘT vụ án hình sự sơ thẩm tại Việt Nam, gốc, không trùng vụ nổi tiếng, không dùng tên người thật của công chúng.

Trả về DUY NHẤT một JSON object (không markdown).

Luật chơi của hồ sơ:
- Áp dụng Bộ luật Hình sự 2015 (sửa đổi, bổ sung 2017; nếu bạn chắc về sửa đổi sau đó thì ghi rõ, không thì đừng bịa số điều). Cáo trạng CÓ THỂ truy tố chưa đúng tội hoặc thiếu tình tiết định khung so với sự thật — đó là nút thắt người chơi phải xét hỏi mới lộ.
- Cấm tội xâm hại tình dục trẻ em và mọi mô tả tình dục. Không mô tả bạo lực máu me dài dòng.
- Chọn đúng cấp tòa: giết người, tham nhũng, ma túy số lượng lớn thường là cấp tỉnh; án nhẹ hơn có thể cấp huyện. courtName là tên tòa hợp lý.
- 7 đến 9 nhân vật trong characters, mỗi người một id ngắn không dấu (bi-cao, ksv, luat-su-bc, bi-hai, nhan-chung-1...). Bắt buộc có: bị cáo, kiểm sát viên, luật sư bào chữa, thư ký, đúng 2 hội thẩm nhân dân (một người nghiêm trị, một người thấu cảm — ghi đúng tên vào layJudges), ít nhất một bị hại hoặc đại diện gia đình bị hại, 2 nhân chứng có lời khai mâu thuẫn. Thêm đúng 1 giám định viên (pháp y, tài chính hoặc tâm thần, đúng loại việc) với present=false, absentReason "Chưa được triệu tập".
- Mỗi nhân vật có personality, secret (điều họ giấu), objective (họ muốn phiên tòa đi về đâu). Bí mật phải khớp với truth.
- evidence: 4 hoặc 5 tình tiết mật. revealed luôn false. unlock ghi rõ hỏi AI, xoáy vào vấn đề gì thì mới lộ. Không để sự thật lộ trong publicSummary.
- twists: đúng 2 biến cố bất ngờ, id "twist-xet-hoi" (phase xet-hoi) và "twist-tranh-luan" (phase tranh-luan). fired false. Biến cố cụ thể: lật lời khai, chứng cứ mới của luật sư, bị cáo ngất hoặc kích động, người nhà lao lên, giám định mâu thuẫn... Không hé trong publicSummary.
- civil: yêu cầu bồi thường có số tiền cụ thể bằng VND, các khoản (mai táng, viện phí, tổn thất tinh thần, tài sản), mức fairAward hợp lý hơn demand, và điểm các bên sẽ cãi.
- correct: kết cục pháp lý đúng nếu xét xử công tâm, gồm điều + khoản + điểm, khung hình phạt, tình tiết giảm nhẹ/tăng nặng thật sự, mức dân sự, vì sao cáo trạng có thể lệch, rủi ro nếu xử oan hoặc bỏ lọt.
- clerk: 140-220 từ, ngôi thứ ba, vai Thư ký. Kiểm tra âm thanh, ổn định trật tự, mời Thẩm phán bước vào, thông báo phòng xử đã sẵn sàng. KHÔNG khai mạc thay thẩm phán, KHÔNG đọc cáo trạng, KHÔNG tiết lộ bí mật. Văn phong trang nghiêm, có không khí.
- publicSummary: 90-140 từ, đúng giọng cáo trạng sơ bộ của cơ quan điều tra, không hé sự thật.
- pressure: số nguyên 30-88, độ nóng dư luận lúc mở phiên.
- memory: một đoạn ngắn ghi "phiên chưa khai mạc".

Mọi chuỗi tiếng Việt có dấu.`;
var SYSTEM_TURN = `Bạn là Quản trò (Game Master) của trò chơi THẨM PHÁN TỐI CAO: PHÁN QUYẾT CỦA BẠN. Người chơi là Thẩm phán chủ tọa phiên tòa hình sự sơ thẩm Việt Nam. Bạn nhập vai TẤT CẢ nhân vật khác và cả không khí phòng xử. Bạn không phải thẩm phán.

Trả về DUY NHẤT một JSON object.

Kỷ luật bất di bất dịch:
- Tuyệt đối không đưa lựa chọn A/B/C, không gợi ý câu hỏi mẫu, không viết hộ lời thẩm phán, không tự chuyển bước khi người chơi chưa ra lệnh.
- Trả lời đúng lệnh vừa rồi. Nếu họ hỏi một người, người đó trả lời trước; sau đó mới tả phản ứng phi ngôn ngữ của những người khác (kiểm sát viên, luật sư, bị hại, gia đình, cảnh sát tư pháp, hội thẩm) và không khí phòng xử.
- Nhân vật có tâm lý động: quanh co, chối, hoảng, thao túng, thành khẩn, đổ lỗi — tùy tính cách trong hồ sơ mật và mức độ bị dồn. Hỏi đúng người, đúng chỗ thì mới lộ tình tiết mật tương ứng (đưa id vào revealedIds và fact vào newRevelations). Không "vô tình" khai hết.
- Không tiết lộ truth, correct, unlock, hay twist chưa kích hoạt. Không nói mình là AI.
- Kiểm sát viên bảo vệ cáo trạng đến cùng, lập luận đanh. Luật sư bào chữa tinh, khoét lỗi tố tụng và tình tiết giảm nhẹ. Phần dân sự phải bị tranh chấp khi bị gọi tới, không tự hòa giải xong.
- Giám định viên chỉ xuất hiện khi thẩm phán hoặc luật sư yêu cầu triệu tập. Khi đó đặt presence của đúng id giám định viên thành present=true và để họ trả lời đúng chuyên môn, khớp truth, không bịa hung khí.
- Biến cố: nếu phase hiện tại là xet-hoi, beatsInPhase >= 4, twist-xet-hoi chưa fired, thì lượt này PHẢI kích hoạt twist đó (twistFiredId), đan vào câu trả lời chứ không thay thế việc trả lời. Nếu phase là tranh-luan, beatsInPhase >= 3 và twist-tranh-luan chưa fired, PHẢI kích hoạt. Không kích hoạt ở khai-mac, nghi-an, tuyen-an. Không quá một twist mỗi lượt. extraDisturbance chỉ true khi cả hai twist đã fired VÀ extras = 0 VÀ phiên đã dài; nếu extras >= 1 thì extraDisturbance=false.
- Hội thẩm: khi vào phòng nghị án, hai hội thẩm tranh luận gay, không dễ đồng ý. Thẩm phán phải lập luận mới kéo được họ. Không bỏ phiếu hộ.
- Trình tự chỉ đi từng bước: khai-mac → xet-hoi → tranh-luan → nghi-an → tuyen-an → ket-thuc. Chỉ tăng đúng một bước, và chỉ khi lệnh của thẩm phán ra lệnh chuyển (khai mạc xong và mời công bố cáo trạng thì sang xet-hoi; kết thúc xét hỏi thì sang tranh-luan; xong tranh luận và lời sau cùng thì sang nghi-an; thống nhất xong và trở lại phòng xử để tuyên thì sang tuyen-an; đã đọc bản án công khai với tội danh, hình phạt hoặc tuyên vô tội, và phần dân sự, thì sang ket-thuc). Nếu họ đòi nhảy cóc, các bên nhắc thủ tục, phase giữ nguyên.
- Hoãn: chỉ đặt phase "hoan" khi lệnh rõ là hoãn / trả hồ sơ điều tra bổ sung. Đánh giá quyết định đó đúng luật hay yếu kém trong score.
- score.include = true CHỈ khi phase bạn đặt là ket-thuc hoặc hoan. Khi đó bắt buộc chấm. Các lượt khác include=false và để chuỗi score rỗng, articles rỗng.
- narration: 200-420 từ tiếng Việt, văn xuôi, không gạch đầu dòng, không menu. Có thể mở đầu đoạn thoại bằng **Tên — vai:** . Lời thoại trong ngoặc kép. Chậm, cụ thể, có mùi phòng xử. Không tóm tắt cả vụ.
- Cuối nội dung không cần viết chỉ số — hệ thống tự hiện. Nhưng pressure và reputation trong JSON phải là số 0-100, chỉ xê dịch nhẹ so với hiện tại trừ khi có biến cố lớn.
- memory: tối đa 900 ký tự, biên bản công khai (ai đã khai gì, bước thủ tục đã xong, dân sự đang kẹt chỗ nào). Không chép truth.

Căn cứ pháp lý được phép viện dẫn khi chắc:
- BLTTHS 2015: Điều 298 giới hạn xét xử; Điều 300, 301 bắt đầu phiên tòa; Điều 306–325 tranh tụng tại phiên tòa (xét hỏi, luận tội, tranh luận, lời sau cùng); Điều 322 tranh luận. Hoãn phiên tòa: nếu không chắc số điều thì nói "quy định hoãn phiên tòa sơ thẩm", đừng bịa số.
- BLHS 2015 sửa đổi 2017: đúng điều, khoản, điểm và khung. Điều 51, 52, 54, 65 chỉ khi áp đúng. BLDS 2015 Điều 584–591 về bồi thường ngoài hợp đồng và tổn thất tinh thần.
- Không bịa điều luật. Nếu không chắc, nói thẳng là còn phải đối chiếu văn bản.

Khi score.include=true:
- kind "an" nếu tuyên án, "hoan" nếu hoãn.
- legalAccuracy 0-100: đối chiếu phán quyết (hoặc quyết định hoãn) với correct và điều luật. Xử đúng tội, đúng khung, đúng khoản định khung, dân sự không vô lý thì cao. Xử oan, bỏ lọt, tử hình khi khung không cho, hoặc hoãn dù chứng cứ đã đủ thì thấp. legalAnalysis 120-200 từ, viện dẫn điều khoản cụ thể.
- empathy 0-100: mức tâm phục khẩu phục của bị cáo, gia đình bị hại và phần công chúng công tâm — không phải chiều đám đông nếu đám đông đòi trái luật. empathyAnalysis 80-150 từ.
- reputationDelta từ -25 đến 20. commentary 50-90 từ, giọng hội đồng thi đua án, thẳng.
- correctOutcome và trueStory: lúc này mới được tiết lộ sự thật và hướng xử đúng, 80-160 từ mỗi trường, tiếng Việt.
- articles: mảng các chuỗi điều luật đã dùng để chấm.`;
function clip(value, max) {
	const text = value.replace(/\s+/g, " ").trim();
	return text.length > max ? text.slice(0, max) : text;
}
function asString(value, fallback = "") {
	return typeof value === "string" ? value.trim() : fallback;
}
function asNumber(value, fallback) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : fallback;
}
function clamp(n, min = 0, max = 100) {
	return Math.max(min, Math.min(max, Math.round(n)));
}
function stepToward(prev, next, maxStep) {
	const n = clamp(next);
	return clamp(Math.max(prev - maxStep, Math.min(prev + maxStep, n)));
}
function slug(input, index) {
	return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32) || `nguoi-${index}`;
}
function extractJson(text) {
	const trimmed = text.trim();
	try {
		return JSON.parse(trimmed);
	} catch {}
	const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
	if (fence?.[1]) try {
		return JSON.parse(fence[1]);
	} catch {}
	const start = trimmed.indexOf("{");
	const end = trimmed.lastIndexOf("}");
	if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
	throw new Error("Phản hồi không đọc được.");
}
async function complete(messages, maxTokens) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) throw new Error("AI chưa sẵn sàng trong môi trường này.");
	const base = {
		model: "grok-4.5",
		messages,
		max_tokens: maxTokens,
		temperature: .85,
		response_format: { type: "json_object" }
	};
	const send = async (body) => {
		return await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify(body),
			signal: AbortSignal.timeout(11e4)
		});
	};
	let res = await send({
		...base,
		reasoning_effort: "low"
	});
	if (res.status === 400) res = await send(base);
	if (!res.ok) {
		const detail = await res.text().catch(() => "");
		console.error("xai court error", res.status, detail.slice(0, 320));
		if (detail.includes("spending-limit") || detail.includes("run out of credits")) throw new Error("Tài khoản AI đã hết hạn mức, nên các nhân vật chưa thể trả lời. Hãy nạp tín dụng Grok hoặc nâng cấp, rồi mở phiên lại. Trò chơi không dùng lời thoại đóng sẵn.");
		if (res.status === 401 || res.status === 403) throw new Error("AI chưa sẵn sàng trong môi trường này.");
		throw new Error(res.status === 429 ? "Phòng xử đang quá tải. Hãy ban hành lại lệnh sau một lúc." : "Đường truyền tới phòng xử bị nghẽn. Hãy ban hành lại lệnh.");
	}
	const content = (await res.json()).choices?.[0]?.message?.content;
	if (!content || !content.trim()) throw new Error("Phòng xử im lặng. Hãy thử lại.");
	return content;
}
function obj(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Hồ sơ không đúng dạng.");
	return value;
}
function stringList(value) {
	if (!Array.isArray(value)) return [];
	return value.map((item) => typeof item === "string" ? item.trim() : "").filter(Boolean).slice(0, 8);
}
function normalizeDossier(raw) {
	const root = obj(raw);
	const source = obj(root.dossier ?? root);
	const characters = (Array.isArray(source.characters) ? source.characters : []).slice(0, 12).map((item, index) => {
		const row = obj(item);
		const name = asString(row.name, `Đương sự ${index + 1}`);
		return {
			id: asString(row.id, slug(name, index)),
			name,
			role: asString(row.role, "Người tham gia"),
			present: row.present !== false,
			absentReason: asString(row.absentReason),
			publicDetail: asString(row.publicDetail || row.detail, "Có mặt theo giấy triệu tập"),
			personality: asString(row.personality, "Giữ khoảng cách, không dễ khai."),
			secret: asString(row.secret, "Còn điểm chưa nói hết."),
			objective: asString(row.objective, "Bảo vệ vị thế của mình.")
		};
	});
	if (characters.length < 6) throw new Error("Hồ sơ thiếu người tham gia.");
	if (!characters.some((c) => /giám định|định giá|chuyên gia/i.test(c.role))) characters.push({
		id: "giam-dinh",
		name: "Nguyễn Hồng Lâm",
		role: "Giám định viên",
		present: false,
		absentReason: "Chưa được triệu tập",
		publicDetail: "Chuyên gia độc lập, đang chờ triệu tập",
		personality: "Điềm tĩnh, chỉ nói trong phạm vi chuyên môn.",
		secret: "Kết luận sẽ khớp sự thật của hồ sơ, không thêm tình tiết.",
		objective: "Trả lời đúng câu hỏi được hỏi."
	});
	const evidence = (Array.isArray(source.evidence) ? source.evidence : []).slice(0, 6).map((item, index) => {
		const row = obj(item);
		return {
			id: asString(row.id, `ev-${index + 1}`),
			fact: asString(row.fact, "Một tình tiết chưa được công bố."),
			unlock: asString(row.unlock, "Hỏi đúng người."),
			revealed: false
		};
	});
	if (evidence.length < 3) throw new Error("Hồ sơ mật quá mỏng.");
	const twists = (Array.isArray(source.twists) ? source.twists : []).slice(0, 2).map((item, index) => {
		const row = obj(item);
		const phase = asString(row.phase) === "tranh-luan" ? "tranh-luan" : "xet-hoi";
		return {
			id: asString(row.id, index === 1 ? "twist-tranh-luan" : "twist-xet-hoi"),
			phase,
			event: asString(row.event, "Một tình huống bất ngờ xảy ra tại tòa."),
			fired: false
		};
	});
	const civilRaw = obj(source.civil ?? {});
	const correctRaw = obj(source.correct ?? {});
	const layRaw = obj(source.layJudges ?? {});
	const title = asString(source.title || root.title);
	const truth = asString(source.truth);
	const article = asString(correctRaw.article);
	if (title.length < 6 || truth.length < 40 || article.length < 3) throw new Error("Hồ sơ chưa đủ sự thật pháp lý.");
	return {
		dossier: {
			courtName: asString(source.courtName || root.courtName, "Tòa án nhân dân"),
			title,
			charge: asString(source.charge || root.charge, "Theo cáo trạng"),
			statute: asString(source.statute || root.statute, article),
			publicSummary: asString(source.publicSummary || root.publicSummary),
			truth,
			indictmentGaps: asString(source.indictmentGaps),
			characters,
			evidence,
			twists,
			civil: {
				claimant: asString(civilRaw.claimant, "Bị hại"),
				demand: asString(civilRaw.demand, "Yêu cầu bồi thường"),
				items: asString(civilRaw.items),
				fairAward: asString(civilRaw.fairAward),
				dispute: asString(civilRaw.dispute)
			},
			correct: {
				crime: asString(correctRaw.crime, title),
				article,
				clause: asString(correctRaw.clause),
				sentence: asString(correctRaw.sentence),
				mitigating: stringList(correctRaw.mitigating),
				aggravating: stringList(correctRaw.aggravating),
				civil: asString(correctRaw.civil),
				why: asString(correctRaw.why),
				wrongfulRisk: asString(correctRaw.wrongfulRisk)
			},
			layJudges: {
				strictName: asString(layRaw.strictName, "Hội thẩm nghiêm trị"),
				strictStance: asString(layRaw.strictStance, "Đòi khung hình phạt nghiêm."),
				lenientName: asString(layRaw.lenientName, "Hội thẩm thấu cảm"),
				lenientStance: asString(layRaw.lenientStance, "Đòi xem hoàn cảnh giảm nhẹ.")
			}
		},
		clerk: asString(root.clerk, "Thư ký phiên tòa đã ổn định trật tự và mời Thẩm phán bước vào phòng xử."),
		atmosphere: asString(root.atmosphere, "Phòng xử im, quạt trần kêu nhẹ, khán giả thì thầm rồi tắt."),
		memory: clip(asString(root.memory, "Phiên chưa khai mạc. Mới có tóm tắt công khai. Chưa xét hỏi."), 900),
		pressure: clamp(asNumber(root.pressure, 55), 30, 88),
		phaseNote: asString(root.phaseNote, "Đang chờ Thẩm phán tuyên bố khai mạc phiên tòa.")
	};
}
function rosterOf(dossier) {
	return dossier.characters.map((c) => ({
		id: c.id,
		name: c.name,
		role: c.role,
		present: c.present,
		absentReason: c.present ? "" : c.absentReason,
		detail: c.publicDetail
	}));
}
function resolvePhase(current, proposed, command) {
	if (current === "ket-thuc" || current === "hoan") return current;
	if (proposed === "hoan" && /hoãn|tra ho so|trả hồ sơ|dieu tra bo sung|điều tra bổ sung/i.test(command)) return "hoan";
	const i = PHASE_ORDER.indexOf(current);
	const j = PHASE_ORDER.indexOf(proposed);
	if (i < 0 || j < 0 || j === i) return current;
	if (j !== i + 1) return current;
	if (proposed === "ket-thuc") return /tuyên|bản án|ban an|phạt|căn cứ|can cu|vô tội|vo toi|có tội|co toi|tử hình|tu hinh|chung thân|chung than|án treo|an treo|miễn trách|mien trach/i.test(command) ? "ket-thuc" : current;
	return proposed;
}
function readScore(raw, kind) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	const include = row.include === true || row.include === "true";
	const legalAnalysis = asString(row.legalAnalysis);
	if (!include && legalAnalysis.length < 40) return null;
	if (legalAnalysis.length < 40) return null;
	const forcedKind = asString(row.kind) === "hoan" ? "hoan" : "an";
	return {
		kind: kind === "hoan" ? "hoan" : forcedKind,
		legalAccuracy: clamp(asNumber(row.legalAccuracy, 0)),
		empathy: clamp(asNumber(row.empathy, 0)),
		legalAnalysis,
		empathyAnalysis: asString(row.empathyAnalysis, "Chưa đủ căn cứ để đo phản ứng các bên."),
		reputationDelta: clamp(asNumber(row.reputationDelta, 0), -25, 20),
		pressureAfter: clamp(asNumber(row.pressureAfter, 50)),
		reputationAfter: clamp(asNumber(row.reputationAfter, 50)),
		articles: stringList(row.articles).slice(0, 6),
		correctOutcome: asString(row.correctOutcome),
		trueStory: asString(row.trueStory),
		commentary: asString(row.commentary)
	};
}
function applyModelTurn(dossier, input, raw) {
	const row = obj(raw);
	const narration = asString(row.narration);
	if (narration.length < 40) throw new Error("Lời phòng xử quá ngắn.");
	const phase = resolvePhase(input.phase, asString(row.phase, input.phase), input.command);
	const closing = phase === "ket-thuc" || phase === "hoan";
	let score = closing ? readScore(row.score, phase === "hoan" ? "hoan" : "an") : null;
	const revealed = [...input.revealed];
	const ids = Array.isArray(row.revealedIds) ? row.revealedIds : [];
	for (const id of ids) {
		if (typeof id !== "string") continue;
		const ev = dossier.evidence.find((item) => item.id === id);
		if (!ev || ev.revealed) continue;
		ev.revealed = true;
		if (!revealed.includes(ev.fact)) revealed.push(ev.fact);
	}
	const extraFacts = stringList(row.newRevelations);
	for (const fact of extraFacts) if (!revealed.includes(fact)) revealed.push(fact.slice(0, 180));
	let twistsFired = input.twistsFired;
	const twistId = asString(row.twistFiredId);
	if (twistId) {
		const twist = dossier.twists.find((item) => item.id === twistId);
		if (twist && !twist.fired) {
			twist.fired = true;
			twistsFired += 1;
		}
	}
	let extras = input.extras;
	if (row.extraDisturbance === true && extras < 2) extras += 1;
	if (Array.isArray(row.presence)) for (const item of row.presence) {
		if (!item || typeof item !== "object") continue;
		const presence = item;
		const id = asString(presence.id);
		const person = dossier.characters.find((c) => c.id === id);
		if (!person) continue;
		person.present = presence.present !== false;
		if (!person.present) person.absentReason = asString(presence.absentReason, person.absentReason || "Vắng mặt");
	}
	const maxRep = closing ? 25 : 6;
	const maxPressure = closing ? 20 : 12;
	let reputation = stepToward(input.reputation, asNumber(row.reputation, input.reputation), maxRep);
	let pressure = stepToward(input.pressure, asNumber(row.pressure, input.pressure), maxPressure);
	if (score) {
		const delta = clamp(score.reputationDelta, -25, 20);
		reputation = clamp(input.reputation + delta);
		pressure = stepToward(input.pressure, score.pressureAfter || pressure, 20);
		score = {
			...score,
			reputationDelta: reputation - input.reputation,
			reputationAfter: reputation,
			pressureAfter: pressure
		};
	}
	return {
		narration,
		atmosphere: asString(row.atmosphere, input.phase === phase ? "Không khí phòng xử đổi rất khẽ." : "Phòng xử chuyển nhịp."),
		phase,
		phaseNote: asString(row.phaseNote, "Đang chờ lệnh tiếp của chủ tọa."),
		pressure,
		reputation,
		revealed: revealed.slice(0, 24),
		twistsFired,
		extras,
		memory: clip(asString(row.memory, input.memory), 900),
		score
	};
}
async function scoreFallback(dossier, input, narration, phase) {
	const kind = phase === "hoan" ? "hoan" : "an";
	return readScoreFromText(await complete([{
		role: "system",
		content: SYSTEM_TURN
	}, {
		role: "user",
		content: JSON.stringify({
			task: "Chỉ chấm điểm. score.include=true. narration để một câu ngắn. Đừng bịa điều luật.",
			phase,
			kind,
			verdict: input.command,
			whatHappened: clip(narration, 1200),
			publicSummary: dossier.publicSummary,
			truth: dossier.truth,
			correct: dossier.correct,
			civil: dossier.civil,
			indictmentGaps: dossier.indictmentGaps
		})
	}], 1800), kind);
}
function readScoreFromText(text, kind) {
	try {
		const row = obj(extractJson(text));
		return readScore({
			...row.score && typeof row.score === "object" ? row.score : row,
			include: true
		}, kind);
	} catch {
		return null;
	}
}
function dossierBrief(dossier, input) {
	return JSON.stringify({
		courtName: dossier.courtName,
		title: dossier.title,
		charge: dossier.charge,
		statute: dossier.statute,
		publicSummary: dossier.publicSummary,
		truth: dossier.truth,
		indictmentGaps: dossier.indictmentGaps,
		characters: dossier.characters,
		evidence: dossier.evidence,
		twists: dossier.twists,
		civil: dossier.civil,
		correct: dossier.correct,
		layJudges: dossier.layJudges,
		state: {
			phase: input.phase,
			pressure: input.pressure,
			reputation: input.reputation,
			revealedPublicly: input.revealed,
			twistsFired: input.twistsFired,
			extras: input.extras,
			beatsInPhase: input.beatsInPhase,
			memory: input.memory,
			recent: input.recent.slice(-8)
		},
		command: input.command
	});
}
function fail(error, fallback) {
	if (error instanceof Error && /AI chưa sẵn sàng|quá tải|nghẽn|im lặng|Hồ sơ|không mở|Lệnh|hết hạn mức/.test(error.message)) return {
		ok: false,
		error: error.message
	};
	console.error("court engine", error);
	return {
		ok: false,
		error: fallback
	};
}
async function runOpen(input) {
	try {
		const caseNumber = clamp(asNumber(input?.caseNumber, 1), 1, 999);
		const reputation = clamp(asNumber(input?.reputation, 64));
		const avoid = Array.isArray(input?.avoidTitles) ? input.avoidTitles.map((t) => asString(t)).filter(Boolean).slice(0, 20) : [];
		const theme = THEMES[(caseNumber - 1) % THEMES.length];
		let last = "Không dựng được hồ sơ. Hãy mở phiên lại.";
		for (let attempt = 0; attempt < 2; attempt++) try {
			const normalized = normalizeDossier(extractJson(await complete([{
				role: "system",
				content: SYSTEM_OPEN
			}, {
				role: "user",
				content: JSON.stringify({
					caseNumber,
					themeHint: theme,
					avoidTitles: avoid,
					judgeReputation: reputation,
					note: attempt === 0 ? "Dựng hồ sơ mới." : "Lần trước không đủ trường. Trả JSON đầy đủ."
				})
			}], 7e3)));
			if (normalized.dossier.publicSummary.length < 40) throw new Error("Hồ sơ chưa đủ sự thật pháp lý.");
			return {
				ok: true,
				seal: sealDossier(normalized.dossier),
				courtName: normalized.dossier.courtName,
				title: normalized.dossier.title,
				charge: normalized.dossier.charge,
				statute: normalized.dossier.statute,
				summary: normalized.dossier.publicSummary,
				roster: rosterOf(normalized.dossier),
				clerk: normalized.clerk,
				atmosphere: normalized.atmosphere,
				memory: normalized.memory,
				pressure: normalized.pressure,
				sealedCount: normalized.dossier.evidence.length,
				phaseNote: normalized.phaseNote
			};
		} catch (error) {
			last = error instanceof Error ? error.message : last;
			console.error("open attempt", attempt, last);
			if (/hết hạn mức|AI chưa|nghẽn|quá tải/.test(last)) break;
		}
		return {
			ok: false,
			error: /Hồ sơ|im lặng|nghẽn|quá tải|AI chưa|hết hạn mức/.test(last) ? last : "Không dựng được hồ sơ. Hãy mở phiên lại."
		};
	} catch (error) {
		return fail(error, "Không dựng được hồ sơ. Hãy mở phiên lại.");
	}
}
async function runTurn(input) {
	try {
		const command = asString(input?.command);
		if (command.length < 1) return {
			ok: false,
			error: "Hãy ra một lệnh."
		};
		if (command.length > 4e3) return {
			ok: false,
			error: "Lệnh quá dài để đưa vào biên bản."
		};
		const dossier = openDossier(asString(input.seal));
		if (!dossier?.truth || !Array.isArray(dossier.characters)) return {
			ok: false,
			error: "Hồ sơ mật không mở được. Hãy mở vụ án mới."
		};
		dossier.evidence = Array.isArray(dossier.evidence) ? dossier.evidence : [];
		dossier.twists = Array.isArray(dossier.twists) ? dossier.twists : [];
		const safeInput = {
			...input,
			command: command.slice(0, 4e3),
			memory: clip(asString(input.memory), 900),
			recent: Array.isArray(input.recent) ? input.recent.slice(-8) : [],
			revealed: Array.isArray(input.revealed) ? input.revealed.slice(0, 24) : [],
			pressure: clamp(asNumber(input.pressure, 50)),
			reputation: clamp(asNumber(input.reputation, 64)),
			twistsFired: clamp(asNumber(input.twistsFired, 0), 0, 9),
			extras: clamp(asNumber(input.extras, 0), 0, 9),
			beatsInPhase: clamp(asNumber(input.beatsInPhase, 0), 0, 40)
		};
		let parsed;
		let last = "Phòng xử chưa trả lời được.";
		for (let attempt = 0; attempt < 2; attempt++) try {
			parsed = extractJson(await complete([{
				role: "system",
				content: SYSTEM_TURN
			}, {
				role: "user",
				content: dossierBrief(dossier, safeInput)
			}], 3200));
			const applied = applyModelTurn(dossier, safeInput, parsed);
			let score = applied.score;
			if ((applied.phase === "ket-thuc" || applied.phase === "hoan") && !score) try {
				score = await scoreFallback(dossier, safeInput, applied.narration, applied.phase);
				if (score) {
					const reputation = clamp(safeInput.reputation + clamp(score.reputationDelta, -25, 20));
					const pressure = stepToward(safeInput.pressure, score.pressureAfter, 20);
					score = {
						...score,
						reputationDelta: reputation - safeInput.reputation,
						reputationAfter: reputation,
						pressureAfter: pressure
					};
					applied.reputation = reputation;
					applied.pressure = pressure;
				}
			} catch (error) {
				console.error("score fallback", error);
			}
			return {
				ok: true,
				seal: sealDossier(dossier),
				narration: applied.narration,
				atmosphere: applied.atmosphere,
				phase: applied.phase,
				phaseNote: applied.phaseNote,
				pressure: applied.pressure,
				reputation: applied.reputation,
				revealed: applied.revealed,
				sealedCount: dossier.evidence.filter((e) => !e.revealed).length,
				twistsFired: applied.twistsFired,
				extras: applied.extras,
				memory: applied.memory,
				roster: rosterOf(dossier),
				score
			};
		} catch (error) {
			last = error instanceof Error ? error.message : last;
			console.error("turn attempt", attempt, last);
			if (/Hồ sơ mật không mở được|AI chưa|quá tải|nghẽn|hết hạn mức/.test(last)) break;
		}
		return {
			ok: false,
			error: /im lặng|nghẽn|quá tải|AI chưa|không mở|Lệnh|ngắn|hết hạn mức/.test(last) ? last : "Phòng xử chưa trả lời được. Hãy ban hành lại lệnh."
		};
	} catch (error) {
		return fail(error, "Phòng xử chưa trả lời được. Hãy ban hành lại lệnh.");
	}
}
//#endregion
export { runOpen, runTurn };
