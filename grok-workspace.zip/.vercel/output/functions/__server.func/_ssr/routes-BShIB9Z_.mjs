import { i as __toESM } from "../_runtime.mjs";
import { U as isRedirect, b as require_jsx_runtime, q as require_react, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as PHASE_ORDER, t as PHASE_LABEL } from "./types-Dn7TblsW.mjs";
import { a as Scale, i as ScrollText, o as Lock, r as Send, s as Gavel, t as Users } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BShIB9Z_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var openCase = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("1c0fa82bd1f18d273955ad4029c7efb66ad651541243491f542a35508218a299"));
var playTurn = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("154b19670001415e4b91bf897d41f5c6120536c63bb72fe7fce0d15a693ef256"));
var EMPTY_CAREER = {
	reputation: 64,
	closed: []
};
function clipRecent(recent) {
	return recent.slice(-8).map((item) => ({
		role: item.role,
		text: item.text.slice(0, 1800)
	}));
}
var useCourt = create()(persist((set) => ({
	career: EMPTY_CAREER,
	session: null,
	begin: (session) => set({ session }),
	noteJudge: (text) => set((state) => {
		if (!state.session) return state;
		const entry = {
			id: `j-${Date.now()}`,
			role: "judge",
			text
		};
		return { session: {
			...state.session,
			log: [...state.session.log, entry].slice(-80),
			recent: clipRecent([...state.session.recent, {
				role: "judge",
				text
			}])
		} };
	}),
	rollbackJudge: () => set((state) => {
		if (!state.session) return state;
		const log = [...state.session.log];
		if (log.at(-1)?.role === "judge") log.pop();
		const recent = [...state.session.recent];
		if (recent.at(-1)?.role === "judge") recent.pop();
		return { session: {
			...state.session,
			log,
			recent
		} };
	}),
	applyTurn: (turn) => set((state) => {
		if (!state.session) return state;
		const prevPhase = state.session.phase;
		const entry = {
			id: `c-${Date.now()}`,
			role: "court",
			text: turn.narration,
			pressure: turn.pressure,
			reputation: turn.reputation
		};
		let career = state.career;
		if (turn.score) {
			const closed = {
				title: state.session.title,
				charge: state.session.charge,
				law: turn.score.legalAccuracy,
				empathy: turn.score.empathy,
				delta: turn.score.reputationDelta,
				kind: turn.score.kind,
				at: Date.now()
			};
			career = {
				reputation: turn.score.reputationAfter,
				closed: [...state.career.closed, closed].slice(-20)
			};
		}
		return {
			career,
			session: {
				...state.session,
				seal: turn.seal,
				roster: turn.roster,
				phase: turn.phase,
				pressure: turn.pressure,
				reputation: turn.reputation,
				revealed: turn.revealed,
				sealedCount: turn.sealedCount,
				twistsFired: turn.twistsFired,
				extras: turn.extras,
				memory: turn.memory,
				phaseNote: turn.phaseNote,
				atmosphere: turn.atmosphere,
				beatsInPhase: turn.phase === prevPhase ? state.session.beatsInPhase + 1 : 0,
				score: turn.score,
				log: [...state.session.log, entry].slice(-80),
				recent: clipRecent([...state.session.recent, {
					role: "court",
					text: turn.narration
				}])
			}
		};
	}),
	abandon: () => set({ session: null })
}), {
	name: "tptc-save-v1",
	skipHydration: true,
	partialize: (state) => ({
		career: state.career,
		session: state.session
	})
}));
var WAITING = [
	"Thư ký đang ghi biên bản…",
	"Phòng xử đang lắng nghe…",
	"Nhân vật đang cân nhắc lời khai…"
];
var PLACEHOLDER = {
	"khai-mac": "Tuyên bố khai mạc, kiểm tra căn cước, giải thích quyền và nghĩa vụ…",
	"xet-hoi": "Hỏi bị cáo, mời kiểm sát viên, luật sư, hoặc triệu tập giám định viên…",
	"tranh-luan": "Điều hành tranh luận, yêu cầu đối đáp, mời bị cáo nói lời sau cùng…",
	"nghi-an": "Lập luận với hai hội thẩm về tội danh, khung hình phạt và phần dân sự…",
	"tuyen-an": "Đọc bản án công khai: tội danh, điều luật, hình phạt, bồi thường…",
	"ket-thuc": "Yêu cầu lập lại bảng tổng kết nếu vừa rồi phòng xử chưa chấm…",
	hoan: "Yêu cầu lập lại bảng tổng kết nếu vừa rồi phòng xử chưa chấm…"
};
function Rich({ text, ink }) {
	const blocks = text.split(/\n{2,}/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: blocks.map((block, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: ink ? "font-serif text-base leading-relaxed text-pretty whitespace-pre-wrap text-inktext" : "font-serif text-base leading-relaxed text-pretty whitespace-pre-wrap text-ivory",
			children: inline(block)
		}, index))
	});
}
function inline(text) {
	return text.split(/(\*\*[^*]+\*\*)/g).map((part, index) => part.startsWith("**") && part.endsWith("**") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
		className: "font-semibold",
		children: part.slice(2, -2)
	}, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, index));
}
function Meter({ label, value, suffix, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-baseline justify-between gap-3 text-xs tracking-wide text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums text-ivory",
			children: [value, suffix]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: tone === "crimson" ? "h-full bg-crimson" : "h-full bg-gold",
			style: { width: `${Math.max(0, Math.min(100, value))}%` }
		})
	})] });
}
function PhaseRail({ phase }) {
	const current = PHASE_ORDER.indexOf(phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: "flex gap-1 overflow-x-auto",
		children: [PHASE_ORDER.slice(0, 5).map((step, index) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "shrink-0 rounded-sm border px-2.5 py-1 text-xs tracking-wide " + (phase === step ? "border-gold bg-gold text-inktext" : current > index || phase === "ket-thuc" ? "border-line text-gold-2" : "border-line text-faint"),
				children: [
					index + 1,
					". ",
					PHASE_LABEL[step]
				]
			}, step);
		}), phase === "hoan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "shrink-0 rounded-sm border border-crimson px-2.5 py-1 text-xs text-ivory",
			children: "Hoãn"
		}) : null]
	});
}
function Roster({ people }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "border-b border-line pb-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ivory",
						children: person.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: person.present ? "text-xs text-gold-2" : "text-xs text-crimson",
						children: person.present ? "Có mặt" : "Vắng"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: person.role
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-faint",
					children: person.present ? person.detail : person.absentReason || person.detail
				})
			]
		}, person.id))
	});
}
function ScoreSheet({ score }) {
	const up = score.reputationDelta >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "paper-shadow relative overflow-hidden rounded-md bg-paper text-inktext",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-paper-2 px-5 py-4 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-crimson",
					children: "BẢN TỔNG KẾT VỤ ÁN"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-serif text-2xl text-balance",
					children: score.kind === "hoan" ? "Quyết định hoãn phiên tòa" : "Sau khi tuyên án"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 px-5 py-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-faint",
							children: "Độ chính xác pháp luật"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-4xl tabular-nums",
							children: [score.legalAccuracy, "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: "Đối chiếu Bộ luật Hình sự"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-faint",
							children: "Thấu tình đạt lý"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-4xl tabular-nums",
							children: [score.empathy, "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: "Gia đình các bên và xã hội"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-faint",
							children: "Thanh danh"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-4xl tabular-nums " + (up ? "text-inktext" : "text-crimson"),
							children: [up ? "+" : "", score.reputationDelta]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-faint",
							children: [
								"Còn ",
								score.reputationAfter,
								"/100 · dư luận ",
								score.pressureAfter,
								"%"
							]
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 px-5 pb-5",
				children: [
					score.articles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-wrap gap-2",
						children: score.articles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-sm border border-paper-2 px-2 py-1 text-xs",
							children: article
						}, article))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-sm font-semibold",
						children: "Đối chiếu pháp luật"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-serif text-sm leading-relaxed text-pretty",
						children: score.legalAnalysis
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-sm font-semibold",
						children: "Phản ứng các bên"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-serif text-sm leading-relaxed text-pretty",
						children: score.empathyAnalysis
					})] }),
					score.trueStory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-sm bg-ink px-4 py-3 text-ivory",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-xs tracking-widest text-gold",
								children: "HỒ SƠ MẬT — MỞ SAU PHIÊN"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-sm leading-relaxed text-pretty",
								children: score.trueStory
							}),
							score.correctOutcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-sm leading-relaxed text-pretty text-gold-2",
								children: score.correctOutcome
							}) : null
						]
					}) : null,
					score.commentary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-sm leading-relaxed text-pretty italic",
						children: score.commentary
					}) : null
				]
			})
		]
	});
}
function FilePanel({ session }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
				label: "Áp lực dư luận",
				value: session.pressure,
				suffix: "%",
				tone: "crimson"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
				label: "Thanh danh thẩm phán",
				value: session.reputation,
				suffix: "/100",
				tone: "gold"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
					className: "size-4 text-gold",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [session.sealedCount, " tình tiết vẫn niêm phong"] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs tracking-widest text-faint",
				children: "ĐÃ LÀM RÕ TẠI TÒA"
			}), session.revealed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-faint",
				children: "Chưa có tình tiết nào vượt khỏi cáo trạng."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: session.revealed.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-l-2 border-gold pl-2 text-sm leading-relaxed text-ivory",
					children: fact
				}, fact))
			})] })
		]
	});
}
function Rules({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 flex items-end justify-center bg-ink/80 p-3 sm:items-center",
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-labelledby": "rules-title",
			className: "paper-shadow max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-md bg-paper p-5 text-inktext",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "rules-title",
					className: "font-serif text-2xl",
					children: "Nội quy phiên tòa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-3 font-serif text-sm leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Bạn là thẩm phán chủ tọa. Gõ lệnh bằng lời của mình. Không có phương án cho sẵn." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Đi đúng thứ tự: khai mạc, xét hỏi, tranh luận, nghị án, tuyên án công khai. Phiên không tự nhảy bước." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Hồ sơ mật, lời khai mâu thuẫn và biến cố giữa phiên chỉ lộ khi bạn hỏi đúng người. Có thể triệu tập giám định viên, giải quyết bồi thường dân sự, hoặc hoãn để trả hồ sơ nếu thủ tục hổng thật sự." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Trong phòng nghị án, hai hội thẩm sẽ không dễ đồng ý với nhau. Sau bản án, tòa chấm độ chính xác pháp luật, mức thấu tình đạt lý, và thanh danh của bạn." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: "Đây là trò chơi giả lập, không phải bản án hay tư vấn pháp lý."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "mt-4 h-11 w-full rounded-sm bg-ink text-sm text-ivory",
					children: "Trở lại"
				})
			]
		})
	});
}
function Game() {
	const career = useCourt((s) => s.career);
	const session = useCourt((s) => s.session);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [rules, setRules] = (0, import_react.useState)(false);
	const [drawer, setDrawer] = (0, import_react.useState)(null);
	const [waitIx, setWaitIx] = (0, import_react.useState)(0);
	const scroller = (0, import_react.useRef)(null);
	const box = (0, import_react.useRef)(null);
	const open = useServerFn(openCase);
	const turn = useServerFn(playTurn);
	(0, import_react.useEffect)(() => {
		const unsub = useCourt.persist.onFinishHydration(() => setReady(true));
		useCourt.persist.rehydrate();
		if (useCourt.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	(0, import_react.useEffect)(() => {
		if (!busy) return;
		const id = window.setInterval(() => setWaitIx((n) => (n + 1) % WAITING.length), 2800);
		return () => window.clearInterval(id);
	}, [busy]);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [
		session?.log.length,
		session?.score,
		busy
	]);
	async function startNew() {
		setConfirm(false);
		setError("");
		setBusy(true);
		const snapshot = useCourt.getState().career;
		const result = await open({ data: {
			caseNumber: snapshot.closed.length + 1,
			reputation: snapshot.reputation,
			avoidTitles: snapshot.closed.map((item) => item.title)
		} });
		setBusy(false);
		if (!result.ok) {
			setError(result.error);
			return;
		}
		useCourt.getState().begin({
			seal: result.seal,
			caseNumber: snapshot.closed.length + 1,
			courtName: result.courtName,
			title: result.title,
			charge: result.charge,
			statute: result.statute,
			summary: result.summary,
			roster: result.roster,
			phase: "khai-mac",
			pressure: result.pressure,
			reputation: snapshot.reputation,
			revealed: [],
			sealedCount: result.sealedCount,
			twistsFired: 0,
			extras: 0,
			memory: result.memory,
			phaseNote: result.phaseNote,
			atmosphere: result.atmosphere,
			log: [{
				id: "clerk-open",
				role: "court",
				text: result.clerk,
				pressure: result.pressure,
				reputation: snapshot.reputation
			}],
			recent: [{
				role: "court",
				text: result.clerk
			}],
			beatsInPhase: 0,
			score: null,
			startedAt: Date.now()
		});
		setDraft("");
	}
	async function send() {
		const text = draft.trim();
		const current = useCourt.getState().session;
		if (!text || !current || busy) return;
		if ((current.phase === "ket-thuc" || current.phase === "hoan") && current.score) return;
		setError("");
		setDraft("");
		useCourt.getState().noteJudge(text);
		setBusy(true);
		const fresh = useCourt.getState().session;
		if (!fresh) {
			setBusy(false);
			return;
		}
		const result = await turn({ data: {
			seal: fresh.seal,
			command: text,
			phase: fresh.phase,
			pressure: fresh.pressure,
			reputation: fresh.reputation,
			memory: fresh.memory,
			recent: fresh.recent,
			revealed: fresh.revealed,
			twistsFired: fresh.twistsFired,
			extras: fresh.extras,
			beatsInPhase: fresh.beatsInPhase
		} });
		setBusy(false);
		if (!result.ok) {
			useCourt.getState().rollbackJudge();
			setDraft(text);
			setError(result.error);
			return;
		}
		useCourt.getState().applyTurn(result);
	}
	if (!session) {
		const closed = career.closed.length;
		const lawAvg = closed ? Math.round(career.closed.reduce((sum, item) => sum + item.law, 0) / closed) : null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-bg min-h-dvh text-ivory",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4 py-8 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs tracking-widest text-gold",
						children: "TÒA ÁN NHÂN DÂN · PHIÊN SƠ THẨM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-6 flex size-16 items-center justify-center rounded-full border border-gold text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, {
							className: "size-8",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-center font-serif text-4xl leading-tight text-balance sm:text-6xl",
						children: "Thẩm Phán Tối Cao"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-sm tracking-widest text-gold-2",
						children: "PHÁN QUYẾT CỦA BẠN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-5 max-w-xl text-center font-serif text-base leading-relaxed text-pretty text-muted",
						children: "Bạn ngồi ghế chủ tọa. Hồ sơ do AI dựng mới mỗi vụ — bạn không biết trước sự thật. Nhân vật trả lời tự do, có thể nói dối, đổ tội, hoặc gãy giữa phiên."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mx-auto mt-6 w-full max-w-xl space-y-2 text-sm text-ivory",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-line pt-2",
								children: "Gõ lệnh tự do. Không có phương án A, B, C."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-line pt-2",
								children: "Chứng cứ mật chỉ lộ khi xét hỏi đúng người."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-line pt-2",
								children: "Kiểm sát viên, luật sư và hội thẩm đấu trí đến cùng."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-line py-2",
								children: "Sau bản án: độ chính xác pháp luật, thấu tình đạt lý, thanh danh."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mt-2 grid w-full max-w-xl grid-cols-3 gap-3 border border-line p-3 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: "Thanh danh"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl tabular-nums text-gold-2",
								children: career.reputation
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: "Án đã khép"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl tabular-nums",
								children: closed
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: "Độ chính xác"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl tabular-nums",
								children: lawAvg === null ? "—" : `${lawAvg}%`
							})] })
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-xl text-center text-sm text-ivory",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mt-5 flex w-full max-w-xl flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !ready || busy,
							onClick: () => void startNew(),
							className: "h-12 flex-1 rounded-sm bg-gold px-4 text-sm font-semibold text-inktext disabled:opacity-60",
							children: busy ? "Thư ký đang niêm phong hồ sơ…" : `Bước vào phòng xử — Vụ án số ${closed + 1}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRules(true),
							className: "h-12 rounded-sm border border-line px-4 text-sm text-ivory",
							children: "Nội quy"
						})]
					}),
					career.closed.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto mt-8 w-full max-w-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs tracking-widest text-faint",
							children: "ÁN ĐÃ TUYÊN"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 divide-y divide-line",
							children: career.closed.slice().reverse().slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-baseline justify-between gap-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-ivory",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-xs tabular-nums text-muted",
									children: [
										"Luật ",
										item.law,
										"% · Tình ",
										item.empathy,
										"% · ",
										item.delta >= 0 ? "+" : "",
										item.delta
									]
								})]
							}, `${item.at}-${item.title}`))
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto pt-8 text-center text-xs text-faint",
						children: "Trò chơi giả lập. Bản án trên màn hình không có hiệu lực pháp lý."
					})
				]
			}), rules ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rules, { onClose: () => setRules(false) }) : null]
		});
	}
	const canSpeak = !(session.phase === "ket-thuc" || session.phase === "hoan") || !session.score;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-bg flex h-dvh flex-col text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-line px-3 py-3 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs tracking-wide text-gold",
							children: session.courtName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-serif text-xl text-balance sm:text-2xl",
							children: session.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRules(true),
							className: "h-11 rounded-sm border border-line px-3 text-xs",
							children: "Nội quy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (session.score) useCourt.getState().abandon();
								else setConfirm(true);
							},
							className: "h-11 rounded-sm border border-line px-3 text-xs",
							children: session.score ? "Về sảnh" : "Rời phiên"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhaseRail, { phase: session.phase })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 lg:grid-cols-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hidden overflow-y-auto border-line px-4 py-4 lg:col-span-3 lg:block lg:border-r",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 flex items-center gap-2 text-xs tracking-widest text-faint",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), " THÀNH PHẦN"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roster, { people: session.roster })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "flex min-h-0 flex-col lg:col-span-6 lg:border-r lg:border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-line px-4 py-2 lg:hidden",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
											label: "Dư luận",
											value: session.pressure,
											suffix: "%",
											tone: "crimson"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
											label: "Thanh danh",
											value: session.reputation,
											suffix: "",
											tone: "gold"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-10 flex-1 rounded-sm border border-line text-xs",
											onClick: () => setDrawer(drawer === "people" ? null : "people"),
											children: "Thành phần"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-10 flex-1 rounded-sm border border-line text-xs",
											onClick: () => setDrawer(drawer === "file" ? null : "file"),
											children: "Hồ sơ"
										})]
									}),
									drawer === "people" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "max-h-52 overflow-y-auto pt-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roster, { people: session.roster })
									}) : null,
									drawer === "file" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "max-h-52 overflow-y-auto pt-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePanel, { session })
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								ref: scroller,
								className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4 sm:px-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "paper-shadow rounded-md bg-paper px-4 py-4 text-inktext sm:px-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-center text-xs tracking-widest text-crimson",
												children: "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-center text-xs",
												children: "Độc lập - Tự do - Hạnh phúc"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "mt-3 text-center font-serif text-xl text-balance",
												children: "Hồ sơ tóm tắt"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
												className: "mt-3 space-y-2 font-serif text-sm leading-relaxed",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-faint",
														children: "Tên vụ án"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: session.title })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-faint",
														children: "Tội danh bị khởi tố"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [session.charge, session.statute ? ` — ${session.statute}` : ""] })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-faint",
														children: "Người được triệu tập"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: session.roster.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "block",
														children: [
															person.role,
															": ",
															person.name,
															person.present ? " — có mặt" : ` — vắng mặt${person.absentReason ? `, ${person.absentReason}` : ""}`
														]
													}, person.id)) })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-faint",
														children: "Diễn biến theo hồ sơ điều tra"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
														className: "text-pretty",
														children: session.summary
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-faint",
														children: "Chỉ số lúc mở phiên"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
														className: "tabular-nums",
														children: [
															"Áp lực dư luận ",
															session.log[0]?.pressure ?? session.pressure,
															"% · Thanh danh",
															" ",
															session.log[0]?.reputation ?? session.reputation,
															"/100"
														]
													})] })
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center font-serif text-sm text-pretty text-muted italic",
										children: session.atmosphere
									}),
									session.phase === "nghi-an" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center text-xs tracking-widest text-gold",
										children: "PHÒNG NGHỊ ÁN — KHÔNG CÓ KHÁN GIẢ"
									}) : null,
									session.log.map((entry) => entry.role === "judge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "ml-6 border-l-2 border-gold py-1 pl-3 sm:ml-16",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-widest text-gold",
											children: "THẨM PHÁN CHỦ TỌA"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rich, {
												text: entry.text,
												ink: false
											})
										})]
									}, entry.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "paper-shadow rounded-md bg-paper px-4 py-4 text-inktext",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mb-2 flex items-center gap-2 text-xs tracking-widest text-crimson",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, {
													className: "size-3.5",
													"aria-hidden": "true"
												}), " PHÒNG XỬ"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rich, {
												text: entry.text,
												ink: true
											}),
											typeof entry.pressure === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-3 border-t border-paper-2 pt-2 text-xs tabular-nums text-faint",
												children: [
													"Áp lực dư luận ",
													entry.pressure,
													"% · Thanh danh ",
													entry.reputation,
													"/100"
												]
											}) : null
										]
									}, entry.id)),
									busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "lamp text-center font-serif text-sm text-gold-2",
										"aria-live": "polite",
										children: WAITING[waitIx]
									}) : null,
									session.score ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreSheet, { score: session.score }) : null,
									error && session.score ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-ivory",
										role: "alert",
										children: error
									}) : null,
									session.score ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void startNew(),
										disabled: busy,
										className: "h-12 w-full rounded-sm bg-gold text-sm font-semibold text-inktext disabled:opacity-60",
										children: busy ? "Đang dựng vụ án mới…" : "Xử vụ án tiếp theo"
									}) : null
								]
							}),
							canSpeak ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "border-t border-line px-3 py-3 sm:px-5",
								onSubmit: (event) => {
									event.preventDefault();
									send();
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "lenh",
										className: "mb-1 flex items-center gap-2 text-xs tracking-widest text-faint",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, {
											className: "size-3.5 text-gold",
											"aria-hidden": "true"
										}), session.phaseNote]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											id: "lenh",
											ref: box,
											value: draft,
											rows: 2,
											disabled: busy,
											placeholder: PLACEHOLDER[session.phase],
											onChange: (event) => setDraft(event.target.value),
											onKeyDown: (event) => {
												if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
													event.preventDefault();
													send();
												}
											},
											className: "max-h-40 min-h-16 flex-1 resize-y rounded-sm border border-line bg-panel px-3 py-2 font-serif text-base text-ivory outline-none placeholder:text-faint focus:border-gold"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											disabled: busy || draft.trim().length === 0,
											className: "flex h-12 w-12 items-center justify-center rounded-sm bg-gold text-inktext disabled:opacity-50",
											"aria-label": "Ban hành lệnh",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
												className: "size-4",
												"aria-hidden": "true"
											})
										})]
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-ivory",
										role: "alert",
										children: error
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-faint",
										children: "Ctrl + Enter để ban hành. Lệnh càng cụ thể, lời khai càng gãy."
									})
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hidden overflow-y-auto px-4 py-4 lg:col-span-3 lg:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 flex items-center gap-2 text-xs tracking-widest text-faint",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), " HỒ SƠ"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePanel, { session })]
					})
				]
			}),
			rules ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rules, { onClose: () => setRules(false) }) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 flex items-end justify-center bg-ink/80 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-labelledby": "leave-title",
					className: "w-full max-w-md rounded-md bg-panel p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "leave-title",
							className: "font-serif text-xl",
							children: "Rời phiên chưa tuyên án?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "Biên bản phiên này sẽ bỏ. Thanh danh giữ nguyên. Vụ án mới là một hồ sơ khác, bạn không xem được tình tiết mật của phiên cũ."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 flex-1 rounded-sm border border-line",
								onClick: () => setConfirm(false),
								children: "Ở lại"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 flex-1 rounded-sm bg-crimson text-ivory",
								onClick: () => {
									useCourt.getState().abandon();
									setConfirm(false);
								},
								children: "Rời phiên"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Game, {});
}
//#endregion
export { Home as component };
