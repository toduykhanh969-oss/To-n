//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-AxSAGEnK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-zmXKYLCD.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-zmXKYLCD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BFKnUQro.js"]
	}
} });
//#endregion
export { tsrStartManifest };
