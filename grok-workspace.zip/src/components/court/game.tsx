import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Gavel,
  Lock,
  Scale,
  ScrollText,
  Send,
  Users,
} from "lucide-react";
import { openCase, playTurn } from "@/lib/court/ai";
import { useCourt } from "@/lib/court/store";
import {
  PHASE_LABEL,
  PHASE_ORDER,
  type Phase,
  type RosterPerson,
  type ScoreCard,
  type Session,
} from "@/lib/court/types";

const WAITING = [
  "Thư ký đang ghi biên bản…",
  "Phòng xử đang lắng nghe…",
  "Nhân vật đang cân nhắc lời khai…",
];

const PLACEHOLDER: Record<Phase, string> = {
  "khai-mac": "Tuyên bố khai mạc, kiểm tra căn cước, giải thích quyền và nghĩa vụ…",
  "xet-hoi": "Hỏi bị cáo, mời kiểm sát viên, luật sư, hoặc triệu tập giám định viên…",
  "tranh-luan": "Điều hành tranh luận, yêu cầu đối đáp, mời bị cáo nói lời sau cùng…",
  "nghi-an": "Lập luận với hai hội thẩm về tội danh, khung hình phạt và phần dân sự…",
  "tuyen-an": "Đọc bản án công khai: tội danh, điều luật, hình phạt, bồi thường…",
  "ket-thuc": "Yêu cầu lập lại bảng tổng kết nếu vừa rồi phòng xử chưa chấm…",
  hoan: "Yêu cầu lập lại bảng tổng kết nếu vừa rồi phòng xử chưa chấm…",
};

function Rich({ text, ink }: { text: string; ink: boolean }) {
  const blocks = text.split(/\n{2,}/);
  return (
    <div className="space-y-3">
      {blocks.map((block, index) => (
        <p
          key={index}
          className={
            ink
              ? "font-serif text-base leading-relaxed text-pretty whitespace-pre-wrap text-inktext"
              : "font-serif text-base leading-relaxed text-pretty whitespace-pre-wrap text-ivory"
          }
        >
          {inline(block)}
        </p>
      ))}
    </div>
  );
}

function inline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, index) =>
    part.startsWith("**") && part.endsWith("**") ? (
      <strong key={index} className="font-semibold">
        {part.slice(2, -2)}
      </strong>
    ) : (
      <span key={index}>{part}</span>
    ),
  );
}

function Meter({
  label,
  value,
  suffix,
  tone,
}: {
  label: string;
  value: number;
  suffix: string;
  tone: "gold" | "crimson";
}) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3 text-xs tracking-wide text-muted">
        <span>{label}</span>
        <span className="tabular-nums text-ivory">
          {value}
          {suffix}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-ink">
        <div
          className={tone === "crimson" ? "h-full bg-crimson" : "h-full bg-gold"}
          style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
        />
      </div>
    </div>
  );
}

function PhaseRail({ phase }: { phase: Phase }) {
  const current = PHASE_ORDER.indexOf(phase as (typeof PHASE_ORDER)[number]);
  return (
    <ol className="flex gap-1 overflow-x-auto">
      {PHASE_ORDER.slice(0, 5).map((step, index) => {
        const done = current > index || phase === "ket-thuc";
        const active = phase === step;
        return (
          <li
            key={step}
            className={
              "shrink-0 rounded-sm border px-2.5 py-1 text-xs tracking-wide " +
              (active
                ? "border-gold bg-gold text-inktext"
                : done
                  ? "border-line text-gold-2"
                  : "border-line text-faint")
            }
          >
            {index + 1}. {PHASE_LABEL[step]}
          </li>
        );
      })}
      {phase === "hoan" ? (
        <li className="shrink-0 rounded-sm border border-crimson px-2.5 py-1 text-xs text-ivory">
          Hoãn
        </li>
      ) : null}
    </ol>
  );
}

function Roster({ people }: { people: RosterPerson[] }) {
  return (
    <ul className="space-y-2">
      {people.map((person) => (
        <li key={person.id} className="border-b border-line pb-2">
          <div className="flex items-baseline justify-between gap-2">
            <p className="text-sm text-ivory">{person.name}</p>
            <span className={person.present ? "text-xs text-gold-2" : "text-xs text-crimson"}>
              {person.present ? "Có mặt" : "Vắng"}
            </span>
          </div>
          <p className="text-xs text-muted">{person.role}</p>
          <p className="text-xs leading-relaxed text-faint">
            {person.present ? person.detail : person.absentReason || person.detail}
          </p>
        </li>
      ))}
    </ul>
  );
}

function ScoreSheet({ score }: { score: ScoreCard }) {
  const up = score.reputationDelta >= 0;
  return (
    <article className="paper-shadow relative overflow-hidden rounded-md bg-paper text-inktext">
      <div className="border-b border-paper-2 px-5 py-4 text-center">
        <p className="text-xs tracking-widest text-crimson">BẢN TỔNG KẾT VỤ ÁN</p>
        <h3 className="mt-1 font-serif text-2xl text-balance">
          {score.kind === "hoan" ? "Quyết định hoãn phiên tòa" : "Sau khi tuyên án"}
        </h3>
      </div>
      <div className="grid gap-4 px-5 py-4 sm:grid-cols-3">
        <div>
          <p className="text-xs tracking-wide text-faint">Độ chính xác pháp luật</p>
          <p className="font-serif text-4xl tabular-nums">{score.legalAccuracy}%</p>
          <p className="text-xs text-faint">Đối chiếu Bộ luật Hình sự</p>
        </div>
        <div>
          <p className="text-xs tracking-wide text-faint">Thấu tình đạt lý</p>
          <p className="font-serif text-4xl tabular-nums">{score.empathy}%</p>
          <p className="text-xs text-faint">Gia đình các bên và xã hội</p>
        </div>
        <div>
          <p className="text-xs tracking-wide text-faint">Thanh danh</p>
          <p className={"font-serif text-4xl tabular-nums " + (up ? "text-inktext" : "text-crimson")}>
            {up ? "+" : ""}
            {score.reputationDelta}
          </p>
          <p className="text-xs text-faint">Còn {score.reputationAfter}/100 · dư luận {score.pressureAfter}%</p>
        </div>
      </div>
      <div className="space-y-4 px-5 pb-5">
        {score.articles.length > 0 ? (
          <ul className="flex flex-wrap gap-2">
            {score.articles.map((article) => (
              <li key={article} className="rounded-sm border border-paper-2 px-2 py-1 text-xs">
                {article}
              </li>
            ))}
          </ul>
        ) : null}
        <section>
          <h4 className="text-sm font-semibold">Đối chiếu pháp luật</h4>
          <p className="mt-1 font-serif text-sm leading-relaxed text-pretty">{score.legalAnalysis}</p>
        </section>
        <section>
          <h4 className="text-sm font-semibold">Phản ứng các bên</h4>
          <p className="mt-1 font-serif text-sm leading-relaxed text-pretty">{score.empathyAnalysis}</p>
        </section>
        {score.trueStory ? (
          <section className="rounded-sm bg-ink px-4 py-3 text-ivory">
            <h4 className="text-xs tracking-widest text-gold">HỒ SƠ MẬT — MỞ SAU PHIÊN</h4>
            <p className="mt-2 font-serif text-sm leading-relaxed text-pretty">{score.trueStory}</p>
            {score.correctOutcome ? (
              <p className="mt-2 font-serif text-sm leading-relaxed text-pretty text-gold-2">
                {score.correctOutcome}
              </p>
            ) : null}
          </section>
        ) : null}
        {score.commentary ? (
          <p className="font-serif text-sm leading-relaxed text-pretty italic">{score.commentary}</p>
        ) : null}
      </div>
    </article>
  );
}

function FilePanel({ session }: { session: Session }) {
  return (
    <div className="space-y-4">
      <Meter label="Áp lực dư luận" value={session.pressure} suffix="%" tone="crimson" />
      <Meter label="Thanh danh thẩm phán" value={session.reputation} suffix="/100" tone="gold" />
      <div className="flex items-center gap-2 text-sm text-muted">
        <Lock className="size-4 text-gold" aria-hidden="true" />
        <span>{session.sealedCount} tình tiết vẫn niêm phong</span>
      </div>
      <div>
        <p className="mb-2 text-xs tracking-widest text-faint">ĐÃ LÀM RÕ TẠI TÒA</p>
        {session.revealed.length === 0 ? (
          <p className="text-sm text-faint">Chưa có tình tiết nào vượt khỏi cáo trạng.</p>
        ) : (
          <ul className="space-y-2">
            {session.revealed.map((fact) => (
              <li key={fact} className="border-l-2 border-gold pl-2 text-sm leading-relaxed text-ivory">
                {fact}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function Rules({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/80 p-3 sm:items-center" role="presentation">
      <div
        role="dialog"
        aria-labelledby="rules-title"
        className="paper-shadow max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-md bg-paper p-5 text-inktext"
      >
        <h2 id="rules-title" className="font-serif text-2xl">
          Nội quy phiên tòa
        </h2>
        <div className="mt-3 space-y-3 font-serif text-sm leading-relaxed">
          <p>Bạn là thẩm phán chủ tọa. Gõ lệnh bằng lời của mình. Không có phương án cho sẵn.</p>
          <p>Đi đúng thứ tự: khai mạc, xét hỏi, tranh luận, nghị án, tuyên án công khai. Phiên không tự nhảy bước.</p>
          <p>
            Hồ sơ mật, lời khai mâu thuẫn và biến cố giữa phiên chỉ lộ khi bạn hỏi đúng người. Có thể triệu tập giám
            định viên, giải quyết bồi thường dân sự, hoặc hoãn để trả hồ sơ nếu thủ tục hổng thật sự.
          </p>
          <p>
            Trong phòng nghị án, hai hội thẩm sẽ không dễ đồng ý với nhau. Sau bản án, tòa chấm độ chính xác pháp luật,
            mức thấu tình đạt lý, và thanh danh của bạn.
          </p>
          <p className="text-xs text-faint">Đây là trò chơi giả lập, không phải bản án hay tư vấn pháp lý.</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="mt-4 h-11 w-full rounded-sm bg-ink text-sm text-ivory"
        >
          Trở lại
        </button>
      </div>
    </div>
  );
}

export function Game() {
  const career = useCourt((s) => s.career);
  const session = useCourt((s) => s.session);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [rules, setRules] = useState(false);
  const [drawer, setDrawer] = useState<"people" | "file" | null>(null);
  const [waitIx, setWaitIx] = useState(0);
  const scroller = useRef<HTMLDivElement>(null);
  const box = useRef<HTMLTextAreaElement>(null);
  const open = useServerFn(openCase);
  const turn = useServerFn(playTurn);

  useEffect(() => {
    const unsub = useCourt.persist.onFinishHydration(() => setReady(true));
    void useCourt.persist.rehydrate();
    if (useCourt.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);

  useEffect(() => {
    if (!busy) return;
    const id = window.setInterval(() => setWaitIx((n) => (n + 1) % WAITING.length), 2800);
    return () => window.clearInterval(id);
  }, [busy]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [session?.log.length, session?.score, busy]);

  async function startNew() {
    setConfirm(false);
    setError("");
    setBusy(true);
    const snapshot = useCourt.getState().career;
    const result = await open({
      data: {
        caseNumber: snapshot.closed.length + 1,
        reputation: snapshot.reputation,
        avoidTitles: snapshot.closed.map((item) => item.title),
      },
    });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    useCourt.getState().begin({
      seal: result.seal,
      caseNumber: snapshot.closed.length + 1,
      courtName: result.courtName,
      title: result.title,
      charge: result.charge,
      statute: result.statute,
      summary: result.summary,
      roster: result.roster,
      phase: "khai-mac",
      pressure: result.pressure,
      reputation: snapshot.reputation,
      revealed: [],
      sealedCount: result.sealedCount,
      twistsFired: 0,
      extras: 0,
      memory: result.memory,
      phaseNote: result.phaseNote,
      atmosphere: result.atmosphere,
      log: [
        {
          id: "clerk-open",
          role: "court",
          text: result.clerk,
          pressure: result.pressure,
          reputation: snapshot.reputation,
        },
      ],
      recent: [{ role: "court", text: result.clerk }],
      beatsInPhase: 0,
      score: null,
      startedAt: Date.now(),
    });
    setDraft("");
  }

  async function send() {
    const text = draft.trim();
    const current = useCourt.getState().session;
    if (!text || !current || busy) return;
    if ((current.phase === "ket-thuc" || current.phase === "hoan") && current.score) return;
    setError("");
    setDraft("");
    useCourt.getState().noteJudge(text);
    setBusy(true);
    const fresh = useCourt.getState().session;
    if (!fresh) {
      setBusy(false);
      return;
    }
    const result = await turn({
      data: {
        seal: fresh.seal,
        command: text,
        phase: fresh.phase,
        pressure: fresh.pressure,
        reputation: fresh.reputation,
        memory: fresh.memory,
        recent: fresh.recent,
        revealed: fresh.revealed,
        twistsFired: fresh.twistsFired,
        extras: fresh.extras,
        beatsInPhase: fresh.beatsInPhase,
      },
    });
    setBusy(false);
    if (!result.ok) {
      useCourt.getState().rollbackJudge();
      setDraft(text);
      setError(result.error);
      return;
    }
    useCourt.getState().applyTurn(result);
  }

  if (!session) {
    const closed = career.closed.length;
    const lawAvg = closed ? Math.round(career.closed.reduce((sum, item) => sum + item.law, 0) / closed) : null;
    return (
      <div className="app-bg min-h-dvh text-ivory">
        <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4 py-8 sm:px-6">
          <p className="text-center text-xs tracking-widest text-gold">TÒA ÁN NHÂN DÂN · PHIÊN SƠ THẨM</p>
          <div className="mx-auto mt-6 flex size-16 items-center justify-center rounded-full border border-gold text-gold">
            <Scale className="size-8" aria-hidden="true" />
          </div>
          <h1 className="mt-5 text-center font-serif text-4xl leading-tight text-balance sm:text-6xl">
            Thẩm Phán Tối Cao
          </h1>
          <p className="mt-2 text-center text-sm tracking-widest text-gold-2">PHÁN QUYẾT CỦA BẠN</p>
          <p className="mx-auto mt-5 max-w-xl text-center font-serif text-base leading-relaxed text-pretty text-muted">
            Bạn ngồi ghế chủ tọa. Hồ sơ do AI dựng mới mỗi vụ — bạn không biết trước sự thật. Nhân vật trả lời tự do,
            có thể nói dối, đổ tội, hoặc gãy giữa phiên.
          </p>
          <ul className="mx-auto mt-6 w-full max-w-xl space-y-2 text-sm text-ivory">
            <li className="border-t border-line pt-2">Gõ lệnh tự do. Không có phương án A, B, C.</li>
            <li className="border-t border-line pt-2">Chứng cứ mật chỉ lộ khi xét hỏi đúng người.</li>
            <li className="border-t border-line pt-2">Kiểm sát viên, luật sư và hội thẩm đấu trí đến cùng.</li>
            <li className="border-t border-line py-2">
              Sau bản án: độ chính xác pháp luật, thấu tình đạt lý, thanh danh.
            </li>
          </ul>
          <div className="mx-auto mt-2 grid w-full max-w-xl grid-cols-3 gap-3 border border-line p-3 text-center">
            <div>
              <p className="text-xs text-faint">Thanh danh</p>
              <p className="font-serif text-2xl tabular-nums text-gold-2">{career.reputation}</p>
            </div>
            <div>
              <p className="text-xs text-faint">Án đã khép</p>
              <p className="font-serif text-2xl tabular-nums">{closed}</p>
            </div>
            <div>
              <p className="text-xs text-faint">Độ chính xác</p>
              <p className="font-serif text-2xl tabular-nums">{lawAvg === null ? "—" : `${lawAvg}%`}</p>
            </div>
          </div>
          {error ? (
            <p className="mx-auto mt-4 max-w-xl text-center text-sm text-ivory" role="alert">
              {error}
            </p>
          ) : null}
          <div className="mx-auto mt-5 flex w-full max-w-xl flex-col gap-2 sm:flex-row">
            <button
              type="button"
              disabled={!ready || busy}
              onClick={() => void startNew()}
              className="h-12 flex-1 rounded-sm bg-gold px-4 text-sm font-semibold text-inktext disabled:opacity-60"
            >
              {busy ? "Thư ký đang niêm phong hồ sơ…" : `Bước vào phòng xử — Vụ án số ${closed + 1}`}
            </button>
            <button
              type="button"
              onClick={() => setRules(true)}
              className="h-12 rounded-sm border border-line px-4 text-sm text-ivory"
            >
              Nội quy
            </button>
          </div>
          {career.closed.length > 0 ? (
            <section className="mx-auto mt-8 w-full max-w-xl">
              <h2 className="text-xs tracking-widest text-faint">ÁN ĐÃ TUYÊN</h2>
              <ul className="mt-2 divide-y divide-line">
                {career.closed
                  .slice()
                  .reverse()
                  .slice(0, 5)
                  .map((item) => (
                    <li key={`${item.at}-${item.title}`} className="flex items-baseline justify-between gap-3 py-2">
                      <span className="text-sm text-ivory">{item.title}</span>
                      <span className="shrink-0 text-xs tabular-nums text-muted">
                        Luật {item.law}% · Tình {item.empathy}% · {item.delta >= 0 ? "+" : ""}
                        {item.delta}
                      </span>
                    </li>
                  ))}
              </ul>
            </section>
          ) : null}
          <p className="mt-auto pt-8 text-center text-xs text-faint">
            Trò chơi giả lập. Bản án trên màn hình không có hiệu lực pháp lý.
          </p>
        </main>
        {rules ? <Rules onClose={() => setRules(false)} /> : null}
      </div>
    );
  }

  const closedCase = session.phase === "ket-thuc" || session.phase === "hoan";
  const canSpeak = !closedCase || !session.score;

  return (
    <div className="app-bg flex h-dvh flex-col text-ivory">
      <header className="border-b border-line px-3 py-3 sm:px-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-xs tracking-wide text-gold">{session.courtName}</p>
            <h1 className="truncate font-serif text-xl text-balance sm:text-2xl">{session.title}</h1>
          </div>
          <div className="flex shrink-0 gap-2">
            <button
              type="button"
              onClick={() => setRules(true)}
              className="h-11 rounded-sm border border-line px-3 text-xs"
            >
              Nội quy
            </button>
            <button
              type="button"
              onClick={() => {
                if (session.score) useCourt.getState().abandon();
                else setConfirm(true);
              }}
              className="h-11 rounded-sm border border-line px-3 text-xs"
            >
              {session.score ? "Về sảnh" : "Rời phiên"}
            </button>
          </div>
        </div>
        <div className="mt-3">
          <PhaseRail phase={session.phase} />
        </div>
      </header>

      <div className="grid min-h-0 flex-1 lg:grid-cols-12">
        <aside className="hidden overflow-y-auto border-line px-4 py-4 lg:col-span-3 lg:block lg:border-r">
          <p className="mb-3 flex items-center gap-2 text-xs tracking-widest text-faint">
            <Users className="size-3.5" aria-hidden="true" /> THÀNH PHẦN
          </p>
          <Roster people={session.roster} />
        </aside>

        <main className="flex min-h-0 flex-col lg:col-span-6 lg:border-r lg:border-line">
          <div className="border-b border-line px-4 py-2 lg:hidden">
            <div className="grid grid-cols-2 gap-3">
              <Meter label="Dư luận" value={session.pressure} suffix="%" tone="crimson" />
              <Meter label="Thanh danh" value={session.reputation} suffix="" tone="gold" />
            </div>
            <div className="mt-2 flex gap-2">
              <button
                type="button"
                className="h-10 flex-1 rounded-sm border border-line text-xs"
                onClick={() => setDrawer(drawer === "people" ? null : "people")}
              >
                Thành phần
              </button>
              <button
                type="button"
                className="h-10 flex-1 rounded-sm border border-line text-xs"
                onClick={() => setDrawer(drawer === "file" ? null : "file")}
              >
                Hồ sơ
              </button>
            </div>
            {drawer === "people" ? (
              <div className="max-h-52 overflow-y-auto pt-3">
                <Roster people={session.roster} />
              </div>
            ) : null}
            {drawer === "file" ? (
              <div className="max-h-52 overflow-y-auto pt-3">
                <FilePanel session={session} />
              </div>
            ) : null}
          </div>

          <div ref={scroller} className="min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4 sm:px-5">
            <article className="paper-shadow rounded-md bg-paper px-4 py-4 text-inktext sm:px-5">
              <p className="text-center text-xs tracking-widest text-crimson">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p>
              <p className="text-center text-xs">Độc lập - Tự do - Hạnh phúc</p>
              <h2 className="mt-3 text-center font-serif text-xl text-balance">Hồ sơ tóm tắt</h2>
              <dl className="mt-3 space-y-2 font-serif text-sm leading-relaxed">
                <div>
                  <dt className="text-xs tracking-wide text-faint">Tên vụ án</dt>
                  <dd>{session.title}</dd>
                </div>
                <div>
                  <dt className="text-xs tracking-wide text-faint">Tội danh bị khởi tố</dt>
                  <dd>
                    {session.charge}
                    {session.statute ? ` — ${session.statute}` : ""}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs tracking-wide text-faint">Người được triệu tập</dt>
                  <dd>
                    {session.roster.map((person) => (
                      <span key={person.id} className="block">
                        {person.role}: {person.name}
                        {person.present ? " — có mặt" : ` — vắng mặt${person.absentReason ? `, ${person.absentReason}` : ""}`}
                      </span>
                    ))}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs tracking-wide text-faint">Diễn biến theo hồ sơ điều tra</dt>
                  <dd className="text-pretty">{session.summary}</dd>
                </div>
                <div>
                  <dt className="text-xs tracking-wide text-faint">Chỉ số lúc mở phiên</dt>
                  <dd className="tabular-nums">
                    Áp lực dư luận {session.log[0]?.pressure ?? session.pressure}% · Thanh danh{" "}
                    {session.log[0]?.reputation ?? session.reputation}/100
                  </dd>
                </div>
              </dl>
            </article>

            <p className="text-center font-serif text-sm text-pretty text-muted italic">{session.atmosphere}</p>
            {session.phase === "nghi-an" ? (
              <p className="text-center text-xs tracking-widest text-gold">PHÒNG NGHỊ ÁN — KHÔNG CÓ KHÁN GIẢ</p>
            ) : null}

            {session.log.map((entry) =>
              entry.role === "judge" ? (
                <article key={entry.id} className="ml-6 border-l-2 border-gold py-1 pl-3 sm:ml-16">
                  <p className="text-xs tracking-widest text-gold">THẨM PHÁN CHỦ TỌA</p>
                  <div className="mt-1">
                    <Rich text={entry.text} ink={false} />
                  </div>
                </article>
              ) : (
                <article key={entry.id} className="paper-shadow rounded-md bg-paper px-4 py-4 text-inktext">
                  <p className="mb-2 flex items-center gap-2 text-xs tracking-widest text-crimson">
                    <ScrollText className="size-3.5" aria-hidden="true" /> PHÒNG XỬ
                  </p>
                  <Rich text={entry.text} ink />
                  {typeof entry.pressure === "number" ? (
                    <p className="mt-3 border-t border-paper-2 pt-2 text-xs tabular-nums text-faint">
                      Áp lực dư luận {entry.pressure}% · Thanh danh {entry.reputation}/100
                    </p>
                  ) : null}
                </article>
              ),
            )}

            {busy ? (
              <p className="lamp text-center font-serif text-sm text-gold-2" aria-live="polite">
                {WAITING[waitIx]}
              </p>
            ) : null}
            {session.score ? <ScoreSheet score={session.score} /> : null}
            {error && session.score ? (
              <p className="text-sm text-ivory" role="alert">
                {error}
              </p>
            ) : null}
            {session.score ? (
              <button
                type="button"
                onClick={() => void startNew()}
                disabled={busy}
                className="h-12 w-full rounded-sm bg-gold text-sm font-semibold text-inktext disabled:opacity-60"
              >
                {busy ? "Đang dựng vụ án mới…" : "Xử vụ án tiếp theo"}
              </button>
            ) : null}
          </div>

          {canSpeak ? (
            <form
              className="border-t border-line px-3 py-3 sm:px-5"
              onSubmit={(event) => {
                event.preventDefault();
                void send();
              }}
            >
              <label htmlFor="lenh" className="mb-1 flex items-center gap-2 text-xs tracking-widest text-faint">
                <Gavel className="size-3.5 text-gold" aria-hidden="true" />
                {session.phaseNote}
              </label>
              <div className="flex items-end gap-2">
                <textarea
                  id="lenh"
                  ref={box}
                  value={draft}
                  rows={2}
                  disabled={busy}
                  placeholder={PLACEHOLDER[session.phase]}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
                      event.preventDefault();
                      void send();
                    }
                  }}
                  className="max-h-40 min-h-16 flex-1 resize-y rounded-sm border border-line bg-panel px-3 py-2 font-serif text-base text-ivory outline-none placeholder:text-faint focus:border-gold"
                />
                <button
                  type="submit"
                  disabled={busy || draft.trim().length === 0}
                  className="flex h-12 w-12 items-center justify-center rounded-sm bg-gold text-inktext disabled:opacity-50"
                  aria-label="Ban hành lệnh"
                >
                  <Send className="size-4" aria-hidden="true" />
                </button>
              </div>
              {error ? (
                <p className="mt-2 text-sm text-ivory" role="alert">
                  {error}
                </p>
              ) : (
                <p className="mt-2 text-xs text-faint">Ctrl + Enter để ban hành. Lệnh càng cụ thể, lời khai càng gãy.</p>
              )}
            </form>
          ) : null}
        </main>

        <aside className="hidden overflow-y-auto px-4 py-4 lg:col-span-3 lg:block">
          <p className="mb-3 flex items-center gap-2 text-xs tracking-widest text-faint">
            <Lock className="size-3.5" aria-hidden="true" /> HỒ SƠ
          </p>
          <FilePanel session={session} />
        </aside>
      </div>
      {rules ? <Rules onClose={() => setRules(false)} /> : null}
      {confirm ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/80 p-3 sm:items-center">
          <div role="dialog" aria-labelledby="leave-title" className="w-full max-w-md rounded-md bg-panel p-5">
            <h2 id="leave-title" className="font-serif text-xl">
              Rời phiên chưa tuyên án?
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Biên bản phiên này sẽ bỏ. Thanh danh giữ nguyên. Vụ án mới là một hồ sơ khác, bạn không xem được tình tiết
              mật của phiên cũ.
            </p>
            <div className="mt-4 flex gap-2">
              <button type="button" className="h-11 flex-1 rounded-sm border border-line" onClick={() => setConfirm(false)}>
                Ở lại
              </button>
              <button
                type="button"
                className="h-11 flex-1 rounded-sm bg-crimson text-ivory"
                onClick={() => {
                  useCourt.getState().abandon();
                  setConfirm(false);
                }}
              >
                Rời phiên
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
