import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scryptSync,
} from "node:crypto";

let cached: Buffer | null = null;

function key(): Buffer {
  if (!cached) {
    const material = process.env.XAI_API_KEY || "preview-seal";
    cached = scryptSync(material, "tptc-seal-v1", 32);
  }
  return cached;
}

export function sealDossier(data: unknown): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const enc = Buffer.concat([
    cipher.update(JSON.stringify(data), "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64url");
}

export function openDossier<T>(sealed: string): T {
  const buf = Buffer.from(sealed, "base64url");
  if (buf.length < 29) throw new Error("Hồ sơ mật không mở được.");
  const iv = buf.subarray(0, 12);
  const tag = buf.subarray(12, 28);
  const enc = buf.subarray(28);
  const decipher = createDecipheriv("aes-256-gcm", key(), iv);
  decipher.setAuthTag(tag);
  const json = Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
  return JSON.parse(json) as T;
}
