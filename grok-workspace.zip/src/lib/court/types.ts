export const PHASE_ORDER = [
  "khai-mac",
  "xet-hoi",
  "tranh-luan",
  "nghi-an",
  "tuyen-an",
  "ket-thuc",
] as const;

export type FlowPhase = (typeof PHASE_ORDER)[number];
export type Phase = FlowPhase | "hoan";

export const PHASE_LABEL: Record<Phase, string> = {
  "khai-mac": "Khai mạc",
  "xet-hoi": "Xét hỏi",
  "tranh-luan": "Tranh luận",
  "nghi-an": "Nghị án",
  "tuyen-an": "Tuyên án",
  "ket-thuc": "Đã tuyên",
  hoan: "Hoãn phiên",
};

export type RosterPerson = {
  id: string;
  name: string;
  role: string;
  present: boolean;
  absentReason: string;
  detail: string;
};

export type LogEntry = {
  id: string;
  role: "court" | "judge";
  text: string;
  pressure?: number;
  reputation?: number;
};

export type ScoreCard = {
  kind: "an" | "hoan";
  legalAccuracy: number;
  empathy: number;
  legalAnalysis: string;
  empathyAnalysis: string;
  reputationDelta: number;
  pressureAfter: number;
  reputationAfter: number;
  articles: string[];
  correctOutcome: string;
  trueStory: string;
  commentary: string;
};

export type ClosedCase = {
  title: string;
  charge: string;
  law: number;
  empathy: number;
  delta: number;
  kind: "an" | "hoan";
  at: number;
};

export type Career = {
  reputation: number;
  closed: ClosedCase[];
};

export type Session = {
  seal: string;
  caseNumber: number;
  courtName: string;
  title: string;
  charge: string;
  statute: string;
  summary: string;
  roster: RosterPerson[];
  phase: Phase;
  pressure: number;
  reputation: number;
  revealed: string[];
  sealedCount: number;
  twistsFired: number;
  extras: number;
  memory: string;
  phaseNote: string;
  atmosphere: string;
  log: LogEntry[];
  recent: { role: "judge" | "court"; text: string }[];
  beatsInPhase: number;
  score: ScoreCard | null;
  startedAt: number;
};

export type OpenInput = {
  caseNumber: number;
  reputation: number;
  avoidTitles: string[];
};

export type OpenResult =
  | { ok: false; error: string }
  | {
      ok: true;
      seal: string;
      courtName: string;
      title: string;
      charge: string;
      statute: string;
      summary: string;
      roster: RosterPerson[];
      clerk: string;
      atmosphere: string;
      memory: string;
      pressure: number;
      sealedCount: number;
      phaseNote: string;
    };

export type TurnInput = {
  seal: string;
  command: string;
  phase: Phase;
  pressure: number;
  reputation: number;
  memory: string;
  recent: { role: "judge" | "court"; text: string }[];
  revealed: string[];
  twistsFired: number;
  extras: number;
  beatsInPhase: number;
};

export type TurnResult =
  | { ok: false; error: string }
  | {
      ok: true;
      seal: string;
      narration: string;
      atmosphere: string;
      phase: Phase;
      phaseNote: string;
      pressure: number;
      reputation: number;
      revealed: string[];
      sealedCount: number;
      twistsFired: number;
      extras: number;
      memory: string;
      roster: RosterPerson[];
      score: ScoreCard | null;
    };
