import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  Career,
  ClosedCase,
  LogEntry,
  Phase,
  ScoreCard,
  Session,
  TurnResult,
} from "./types.ts";

type CourtStore = {
  career: Career;
  session: Session | null;
  begin: (session: Session) => void;
  noteJudge: (text: string) => void;
  rollbackJudge: () => void;
  applyTurn: (turn: Extract<TurnResult, { ok: true }>) => void;
  abandon: () => void;
};

const EMPTY_CAREER: Career = { reputation: 64, closed: [] };

function clipRecent(
  recent: { role: "judge" | "court"; text: string }[],
): { role: "judge" | "court"; text: string }[] {
  return recent.slice(-8).map((item) => ({
    role: item.role,
    text: item.text.slice(0, 1800),
  }));
}

export const useCourt = create<CourtStore>()(
  persist(
    (set) => ({
      career: EMPTY_CAREER,
      session: null,
      begin: (session) => set({ session }),
      noteJudge: (text) =>
        set((state) => {
          if (!state.session) return state;
          const entry: LogEntry = {
            id: `j-${Date.now()}`,
            role: "judge",
            text,
          };
          return {
            session: {
              ...state.session,
              log: [...state.session.log, entry].slice(-80),
              recent: clipRecent([
                ...state.session.recent,
                { role: "judge", text },
              ]),
            },
          };
        }),
      rollbackJudge: () =>
        set((state) => {
          if (!state.session) return state;
          const log = [...state.session.log];
          if (log.at(-1)?.role === "judge") log.pop();
          const recent = [...state.session.recent];
          if (recent.at(-1)?.role === "judge") recent.pop();
          return { session: { ...state.session, log, recent } };
        }),
      applyTurn: (turn) =>
        set((state) => {
          if (!state.session) return state;
          const prevPhase: Phase = state.session.phase;
          const entry: LogEntry = {
            id: `c-${Date.now()}`,
            role: "court",
            text: turn.narration,
            pressure: turn.pressure,
            reputation: turn.reputation,
          };
          let career = state.career;
          if (turn.score) {
            const closed: ClosedCase = {
              title: state.session.title,
              charge: state.session.charge,
              law: turn.score.legalAccuracy,
              empathy: turn.score.empathy,
              delta: turn.score.reputationDelta,
              kind: turn.score.kind,
              at: Date.now(),
            };
            career = {
              reputation: turn.score.reputationAfter,
              closed: [...state.career.closed, closed].slice(-20),
            };
          }
          return {
            career,
            session: {
              ...state.session,
              seal: turn.seal,
              roster: turn.roster,
              phase: turn.phase,
              pressure: turn.pressure,
              reputation: turn.reputation,
              revealed: turn.revealed,
              sealedCount: turn.sealedCount,
              twistsFired: turn.twistsFired,
              extras: turn.extras,
              memory: turn.memory,
              phaseNote: turn.phaseNote,
              atmosphere: turn.atmosphere,
              beatsInPhase:
                turn.phase === prevPhase ? state.session.beatsInPhase + 1 : 0,
              score: turn.score,
              log: [...state.session.log, entry].slice(-80),
              recent: clipRecent([
                ...state.session.recent,
                { role: "court", text: turn.narration },
              ]),
            },
          };
        }),
      abandon: () => set({ session: null }),
    }),
    {
      name: "tptc-save-v1",
      skipHydration: true,
      partialize: (state) => ({ career: state.career, session: state.session }),
    },
  ),
);

export function scoreOf(session: Session | null): ScoreCard | null {
  return session?.score ?? null;
}
