import { createServerFn } from "@tanstack/react-start";
import type { OpenInput, OpenResult, TurnInput, TurnResult } from "./types.ts";

export const openCase = createServerFn({ method: "POST" })
  .validator((input: OpenInput) => input)
  .handler(async ({ data }): Promise<OpenResult> => {
    const { runOpen } = await import("./engine.server.ts");
    return runOpen(data);
  });

export const playTurn = createServerFn({ method: "POST" })
  .validator((input: TurnInput) => input)
  .handler(async ({ data }): Promise<TurnResult> => {
    const { runTurn } = await import("./engine.server.ts");
    return runTurn(data);
  });
